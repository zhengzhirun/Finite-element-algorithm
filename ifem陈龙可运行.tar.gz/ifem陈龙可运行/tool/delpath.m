%% Delete path
%
% Delete all subdirectories under pathstr to search path.
%
% Copyright (C) Long Chen. See COPYRIGHT.txt for details. 

rmpath(genpath(pwd));
savepath;