%% Adaptive Mesh Refinement/Coarsening
% 
%% Uniform refinement

%% Bisection in 2-D 

%% Bisection in 3-D

%% Coarsening in 2-D

%% Coarsening in 3-D
