double a_cos(double c);

double fmin(double f1,double f2);

double fmax(double f1,double f2);

double dot_Product(double p0[],double p1[]);

double get_C_Distance(double pt0[],double pt1[]);

double get_C_Area(double pt0[],double pt1[],double pt2[]);

double dcircle(double pt[],double xc,double yc,double r);

double drectangle(double pt[],double lv[],double rv[]);

double get_P_S_Distance(double pt[],double p0[],double p1[]);

double dpoly(double pt[],double vx[],double vy[],int n);

double dunion(double d1,double d2);

double ddiff(double d1,double d2);

double dintersect(double d1,double d2);

void  pshift(double pt[],double x0,double y0,double ps[]);

void  protate(double pt[],double phi,double ps[]);

double fx(double (*ff)(double []),double pt[]);

double fy(double (*ff)(double []),double pt[]);

double fxx(double (*ff)(double []),double pt[]);

double fyy(double (*ff)(double []),double pt[]);

double fxy(double (*ff)(double []),double pt[]);

double dlevel(double (*ff)(double []),double p0[]);

void  proj_Curv_Boundary(double (*df)(double []),double pt[]);
