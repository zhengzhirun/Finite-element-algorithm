#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <fstream>
#include "ANN.h"

#include "assist.h"

using namespace std;

double radi = 6371000;

double df(double pt[]);

/*********************************************************/
/*Using the df() function to define the density explicitly*/
/*********************************************************/
/*
double get_Density(double pt[])
{
  double x,y,lambda;

  x = 0.5*pt[0]/radi; 
  y = 0.5*pt[1]/radi;
  lambda = 1.0/(1+x*x+y*y);
  return exp(-10.0*fabs(df(pt)));
}
*/

/*****Constant density*****/ 

double get_Density(double pt[])
{
  return 1.0;
}


/*****Example density for square.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  dist = sqrt(pt[0]*pt[0]+pt[1]*pt[1]);
                                                                                
  return exp(-8.0*dist);
}
*/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  dist = sqrt((pt[0]-1.0)*(pt[0]-1.0)+(pt[1]-1.0)*(pt[1]-1.0));
                                                                                
  return exp(-6.0*dist);
}
*/
/*
double get_Density(double pt[])
{
  double  dist;
  
  if ((pt[0]>=0)&&(pt[1]>=0))
     dist = sqrt((pt[0]-0.5)*(pt[0]-0.5)+(pt[1]-0.5)*(pt[1]-0.5));
  else if ((pt[0]<=0)&&(pt[1]<=0))
     dist = sqrt((pt[0]+0.5)*(pt[0]+0.5)+(pt[1]+0.5)*(pt[1]+0.5));
  else
     dist = fmin(sqrt((pt[0]-0.5)*(pt[0]-0.5)+(pt[1]-0.5)*(pt[1]-0.5)),
                  sqrt((pt[0]+0.5)*(pt[0]+0.5)+(pt[1]+0.5)*(pt[1]+0.5)));
  
  return exp(-10.0*dist);
}
*/

/*****Example density for L_shape.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  dist = sqrt(pt[0]*pt[0]+pt[1]*pt[1]);
                                                                                
  return exp(-6.0*dist);
}
*/


/*****Example density for hexagon.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  dist = sqrt(pt[0]*pt[0]+pt[1]*pt[1]);
                                                                                
  return exp(-6.0*dist);
}
*/


/*****Example density for slit.poly*****/
/*
double get_Density(double pt[])
{
  double  d1,d2,dist;
                                                                                
  d1 = sqrt(pt[0]*pt[0]+(pt[1]-0.5)*(pt[1]-0.5));
  d2 = sqrt(pt[0]*pt[0]+(pt[1]+0.5)*(pt[1]+0.5));
  dist = fmin(d1,d2);
  if (dist>0.5) dist = 0.5;
                                                                                
  return exp(-15.0*dist);
}
*/


/*****Example density for squa_in_squa.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;

  if ((pt[0]>=0)&&(pt[1]>=0))
     dist = sqrt((pt[0]-0.5)*(pt[0]-0.5)+(pt[1]-0.5)*(pt[1]-0.5));
  if ((pt[0]<=0)&&(pt[1]>=0))
     dist = sqrt((pt[0]+0.5)*(pt[0]+0.5)+(pt[1]-0.5)*(pt[1]-0.5));
  if ((pt[0]<=0)&&(pt[1]<=0))
     dist = sqrt((pt[0]+0.5)*(pt[0]+0.5)+(pt[1]+0.5)*(pt[1]+0.5));
  if ((pt[0]>=0)&&(pt[1]<=0))
     dist = sqrt((pt[0]-0.5)*(pt[0]-0.5)+(pt[1]+0.5)*(pt[1]+0.5));

  return exp(-10.0*dist);
}
*/


/*****Example density for 4squa_in_squa.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  if ((pt[0]>=0)&&(pt[1]>=0))
     dist = sqrt((pt[0]-0.5)*(pt[0]-0.5)+(pt[1]-0.5)*(pt[1]-0.5));
  if ((pt[0]<=0)&&(pt[1]>=0))
     dist = sqrt((pt[0]+0.5)*(pt[0]+0.5)+(pt[1]-0.5)*(pt[1]-0.5));
  if ((pt[0]<=0)&&(pt[1]<=0))
     dist = sqrt((pt[0]+0.5)*(pt[0]+0.5)+(pt[1]+0.5)*(pt[1]+0.5));
  if ((pt[0]>=0)&&(pt[1]<=0))
     dist = sqrt((pt[0]-0.5)*(pt[0]-0.5)+(pt[1]+0.5)*(pt[1]+0.5));
                                                                                
  return exp(-15.0*fabs(dist-0.4));
}
*/


/*****Example density for 2hexa_in_squa.poly*****/
/*
double get_Density(double pt[])
{
  double  dist,x1,y1,x2,y2,d1,d2;

  x1 = 0.26667; y1 = 0.75;
  x2 = 0.6;     y2 = 0.40;  
  d1 = sqrt((pt[0]-x1)*(pt[0]-x1)+(pt[1]-y1)*(pt[1]-y1));
  d2 = sqrt((pt[0]-x2)*(pt[0]-x2)+(pt[1]-y2)*(pt[1]-y2));
  dist = fmin(d1,d2);

  return exp(-20.0*fabs(dist-0.1));
}
*/


/*****Example density for hexa_in_hexa.poly*****/
/*
double get_Density(double pt[])
{
  double  dist,x,y;
                                                                                
  x = 0.0; y = 0.0;
  dist = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
                                                                                
  return exp(-15.0*fabs(dist-0.5));
}
*/


/*****Example density for circle.poly*****/
/*
double get_Density(double pt[])
{
  double  dist,x,y;
                                                                                
  x = 0.0; y = 0.0;
  dist = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
                                                                                
  return exp(-10.0*dist);
}
*/
/*
double get_Density(double pt[])
{
  double  dist,x,y;
                                                                                
  x = 0.0; y = 0.0;
  dist = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
                                                                                
  return exp(-10.0*fabs(dist-1.0));
}
*/


/*****Example density for circ_in_circ.poly*****/
/*
double get_Density(double pt[])
{
  double  dist,x,y;
                                                                                
  x = 0.0; y = 0.0;
  dist = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
                                                                                
  return exp(-10.0*fabs(dist-0.5));
}
*/


/*****Example density for circ_in_squa.poly*****/
/*
double get_Density(double pt[])
{
  double  dist,x,y;
                                                                                
  x = 0.0; y = 0.0;
  dist = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
                                                                                
  return exp(-10.0*fabs(dist-0.5));
}
*/


/*****Example density for hexa_in_circ.poly*****/
/*
double get_Density(double pt[])
{
  double  dist,x,y;
                                                                                
  x = 0.0; y = 0.0;
  dist = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
                                                                                
  return exp(-10.0*fabs(dist-0.5));
}
*/


/*****Example density for circ_in_poly.poly*****/
/*                                                     
double get_Density(double pt[])
{
  double  dist,x,y,d1,d2,d3;
                                                                                
  x = 0.0; y = 0.0;
  d1 = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
  x = -2.5; y = 0.0;
  d2 = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
  x = 1.0; y = 0.0;
  d3 = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
  dist = fmin(d1,fmin(d2,d3));

  return exp(-5.0*fabs(dist));
}
*/


/*****Example density for 2half_circ.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  dist = sqrt((pt[0]+1.0)*(pt[0]+1.0)+pt[1]*pt[1]);
                                                                                
  return exp(-5.0*dist);
}
*/


/*****Example density for selipse.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  dist = sqrt(pt[0]*pt[0]+pt[1]*pt[1]);
                                                                                
  return exp(-5.0*dist);
}
*/


/*****Example density for seli_in_seli.poly*****/
/*
double get_Density(double pt[])
{
  double  dist;
                                                                                
  dist = sqrt(pt[0]*pt[0]+pt[1]*pt[1]);
                                                                                
  return exp(-10.0*fabs(dist-0.5));
}
*/


/*****Example density for PIshape.poly*****/
/*
double get_Density(double pt[])
{
  double  dist,x,y;
                                                                                
  x = 0.0; y = -1.0;
  dist = sqrt((pt[0]-x)*(pt[0]-x)+(pt[1]-y)*(pt[1]-y));
                                                                                
  return exp(-dist);
}
*/


/*********************************************************/
/*Define the density through a set of background nodes 
  saved in "dens_nodes.dat" and their correspnoding values 
  saved in "dens_valus.dat*/
/*********************************************************/

/***variable defined for ANN fast searching***/
int     k=1,dim=3,maxPts=1000000,nPts;
double  anneps=1.0e-3,*denValues;
istream*  dataIn=NULL;
ANNpointArray dataPts;
ANNpoint      queryPt;
ANNidxArray   nnIdx;
ANNdistArray  dists;
ANNkd_tree*   kdTree;
/***read background nodes coordinate information***/
void getNodesData()
{
  static ifstream dataStream;
                             
  dataStream.open("dens_nodes.dat", ios::in);
  if (!dataStream) {
     cerr << "Cannot open nodes file for density!\n";
     exit(1);
  }
  dataIn = &dataStream;
}
/***read background nodes density information***/
void getValusData()
{
  FILE*  fp;
  float  ftemp;
  int    i;
                                                                                                      
  fp = fopen("dens_valus.dat","rt");
  denValues = (double*)calloc(nPts,sizeof(double));
  for (i=0;i<nPts;i++) {
      fscanf(fp,"%f",&ftemp);
      denValues[i] = ftemp;
  }
  fclose(fp);
}
bool readPt(istream &in, ANNpoint p)
{
  for (int i=0;i<dim;i++) {
      if(!(in >> p[i])) return false;
  }
  return true;
}
/***Build the Kdtree***/
void build_Kdtree()
{
  getNodesData();

  dataPts = annAllocPts(maxPts, dim);
  nnIdx = new ANNidx[k];
  dists = new ANNdist[k];
  nPts = 0;
  while (nPts<maxPts && readPt(*dataIn, dataPts[nPts])) {
        nPts++;
  }
  kdTree = new ANNkd_tree(dataPts,nPts,dim);
  getValusData();
}
void free_Dens_Memory()
{
  free(denValues);
  delete [] nnIdx;
  delete [] dists;
  delete kdTree;
  annClose();
}

/*****Example density using background nodes*****/
/*
double get_Density(double pt[]) 
{
  double radi = 6371000;
  double den,sp_pt[3],x,y,xy2;

  x = 0.5*pt[0]/radi;
  y = 0.5*pt[1]/radi;
  xy2 = x*x+y*y;
  sp_pt[0] = radi*2*x/(1+xy2);
  sp_pt[1] = radi*2*y/(1+xy2);
  sp_pt[2] = radi*(1-xy2)/(1+xy2);
  kdTree->annkSearch(sp_pt,k,nnIdx,dists,anneps);
  den = denValues[nnIdx[0]];  

  return den;
}
*/
