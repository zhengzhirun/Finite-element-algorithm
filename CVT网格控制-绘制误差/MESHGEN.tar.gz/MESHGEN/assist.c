#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/wait.h>
#include <fstream>
#define dJ 1.0e-10
#define deps 1.0e-6
#define mitr 10
#define epsl 1.0e-8
#define alpha 1.0
#define PI 3.1415926535897932


/*****"arccos" function without overflow*****/
double a_cos(double c)
{
  if (c<=-1.0)
     return PI;
  else if (c>=1.0)
     return 0.0; 
  else   
     return acos (c);
}

/*****Find the minimum of f1 and f2*****/
double fmin(double f1,double f2)
{ 
  if (f1>f2)
     return f2;
  else
     return f1;
}     
  
/*****Find the maximum of f1 and f2*****/  
double fmax(double f1,double f2)
{
  if (f1>f2)
     return f1;
  else
     return f2;
}

/*****Compute the Dot-Product of two vectors v0 and v1*****/
double dot_Product(double p0[],double p1[])
{
  double dd;

  dd = p0[0]*p1[0]+p0[1]*p1[1];

  return dd;
}


/*****Compute the distance of two points pt0 and pt1*****/
double get_C_Distance(double pt0[], double pt1[])
{
  double dist,tt;
  int    i;
      
  dist = 0.0;
  for (i=0;i<2;i++) {
      tt = pt0[i]-pt1[i];
      dist += tt*tt;
  }
 
  return sqrt(dist);
}


/*****Compute the area of the triangle form by three points 
      (pt0,pt1,pt2)*****/
double get_C_Area(double pt0[],double pt1[],double pt2[])
{
  double area,a[2],b[2];
  int    i;

  for (i=0;i<2;i++) {
      a[i]=pt1[i]-pt0[i];
      b[i]=pt2[i]-pt0[i];
  }
  area = a[0]*b[1]-a[1]*b[0];
  if (area>=0)
     area = 0.5*area;
  else
     area = -0.5*area;
      
  return area;
}  


/**********************************************************/
/*Begin of Special Functions*/
/**********************************************************/
                                                                                
/*****Signed distance from a point to a circle*****/
double dcircle(double pt[],double xc,double yc,double r)
{
  double dist;
                                                                               
  dist = sqrt((pt[0]-xc)*(pt[0]-xc)+(pt[1]-yc)*(pt[1]-yc))-r;
                                                                                
  return dist;
}
                                                                                
                                                                                
/*****Signed distance to a point to a rectangle*****/
double drectangle(double pt[],double lv[],double rv[])
{
   double dist;
                                                                                
   dist = -fmin(fmin(fmin(-lv[1]+pt[1],rv[1]-pt[1]),
                     -lv[0]+pt[0]),rv[0]-pt[0]);
                                                                                
   return dist;
}
                                                                                

/*****Distance from a point to a segment*****/
double get_P_S_Distance(double pt[],double p0[],double p1[])
{
  int    j;
  double v[2],w[2],pb[2],c1,c2,b;
                                                                                
  for (j=0;j<2;j++) {
      v[j] = p1[j]-p0[j];
      w[j] = pt[j]-p0[j];
  }
  c1 = dot_Product(v,w);
  c2 = dot_Product(v,v);
  if (c1<=0) {
     return get_C_Distance(pt,p0);
  }
  else if (c2<=c1) {
     return get_C_Distance(pt,p1);
  }
  else {
     b = c1/c2;
     for (j=0;j<2;j++) pb[j] = p0[j]+b*v[j];
     return get_C_Distance(pt,pb);
  }
}


/*****Signed distance from a point to a polygon*****/
/*The vertices of the polygon must be ordered counterclockwisely*/
double dpoly(double pt[],double vx[],double vy[],int n)
{
  int    i,j,k,ik;
  double p0[2],p1[2],v[2],w[2],dist,dist1,ss[n];
                                                                                
  dist = 1.0e15;
  for (i=0;i<n;i++) {
      for (j=0;j<2;j++) {
          p0[0] = vx[(i+j)%n];
          p0[1] = vy[(i+j)%n];
          p1[0] = vx[(i+j+1)%n];
          p1[1] = vy[(i+j+1)%n];
      }
      dist1 = fmin(dist,get_P_S_Distance(pt,p0,p1));
      if (dist1<dist) ik = i;
      dist = dist1;
      for (j=0;j<2;j++) {
          v[j] = p1[j]-p0[j];
          w[j] = pt[j]-p0[j];
      }
      ss[i] = v[0]*w[1]-v[1]*w[0];
  }
  if (ss[ik]>=0)
     return -dist;
  else
     return dist;
}
                                                                                
                                                                                
/*****Signed distance to the union of two domains*****/
double dunion(double d1,double d2)
{
  return fmin(d1,d2);
}
                                                                                
                                                                                
/*****Signed distance to the difference of two domains*****/
double ddiff(double d1,double d2)
{
  return fmax(d1,-d2);
}


/*****Signed distance to the intersection of two domains*****/
double dintersect(double d1,double d2)
{
  return fmax(d1,d2);
}
                                                                                
                                                                                
/*****Shift a point by (x0,y0)*****/
double pshift(double pt[],double x0,double y0,double ps[])
{
  ps[0] = pt[0]-x0;
  ps[1] = pt[1]-y0;
}
                                                                                
                                                                                
/*****Rotate a point counterclockwisely by phi*****/
void protate(double pt[],double phi,double pr[])
{
  pr[0] = pt[0]*cos(phi)+pt[1]*sin(phi);
  pr[1] =-pt[0]*sin(phi)+pt[1]*cos(phi);
}

/**********************************************************/
/*End of Special Functions*/
/**********************************************************/

/**********************************************************/
/*Signed distance when implicit level set function ff used*/
/**********************************************************/
/***Compute f_x***/                           
double fx(double (*ff)(double []),double pt[])
{
  double func,psl[2],psr[2];
                                                                                
  psl[0] = pt[0]-0.5*deps; psl[1] = pt[1];
  psr[0] = pt[0]+0.5*deps; psr[1] = pt[1];
  func = (ff(psr)-ff(psl))/deps;
                                                                                
  return func;
}
/***Compute f_y***/
double fy(double (*ff)(double []),double pt[])
{
  double func,psb[2],psu[2];
                                                                                
  psb[0] = pt[0]; psb[1] = pt[1]-0.5*deps;
  psu[0] = pt[0]; psu[1] = pt[1]+0.5*deps;
  func = (ff(psu)-ff(psb))/deps;
                                                                                
  return func;
}
/***Compute f_{xx}***/
double fxx(double (*ff)(double []),double pt[])
{
  double func,f1,f2,psl[2],psr[2];
                                                                                
  psl[0] = pt[0]-deps; psl[1] = pt[1];
  psr[0] = pt[0]+deps; psr[1] = pt[1];
  f1 = (ff(pt)-ff(psl))/deps;
  f2 = (ff(psr)-ff(pt))/deps;
  func = (f2-f1)/deps;
                                                                                
  return func;
}
/***Compute f_{yy}***/
double fyy(double (*ff)(double []),double pt[])
{
  double func,f1,f2,psb[2],psu[2];
                                                                                
  psb[0] = pt[0]; psb[1] = pt[1]-deps;
  psu[0] = pt[0]; psu[1] = pt[1]+deps;
  f1 = (ff(pt)-ff(psb))/deps;
  f2 = (ff(psu)-ff(pt))/deps;
  func = (f2-f1)/deps;
                                                                                
  return func;
}
/***Compute f_{xy}***/
double fxy(double (*ff)(double []),double pt[])
{
  double func,f1,f2,psl[2],psr[2];
                                                                                
  psl[0] = pt[0]-0.5*deps; psl[1] = pt[1]-0.5*deps;
  psr[0] = pt[0]+0.5*deps; psr[1] = pt[1]-0.5*deps;
  f1 = (ff(psr)-ff(psl))/deps;
  psl[0] = pt[0]-0.5*deps; psl[1] = pt[1]+0.5*deps;
  psr[0] = pt[0]+0.5*deps; psr[1] = pt[1]+0.5*deps;
  f2 = (ff(psr)-ff(psl))/deps;
  func = (f2-f1)/deps;
                                                                                
  return func;
}

/*****Signed distance to the level set ff=0*****/
double dlevel(double (*ff)(double []),double p0[])
{
  int    i,j;
  double pt[2],L[2],J[2][2],Jinv[2][2];
  double dn[2],det,dm,dist;
                                                                                
  for (i=0;i<2;i++) pt[i] = p0[i];
  for (i=0;i<mitr;i++) {
      L[0] = ff(pt);
      L[1] = (pt[0]-p0[0])*fy(ff,pt)-(pt[1]-p0[1])*fx(ff,pt);
      J[0][0] = fx(ff,pt);
      J[0][1] = fy(ff,pt);
      J[1][0] = fy(ff,pt)
                +(pt[0]-p0[0])*fxy(ff,pt)-(pt[1]-p0[1])*fxx(ff,pt);
      J[1][1] =-fx(ff,pt)
                -(pt[1]-p0[1])*fxy(ff,pt)+(pt[0]-p0[0])*fyy(ff,pt);
      det = J[0][0]*J[1][1]-J[1][0]*J[0][1];
      if (fabs(det)<dJ) break;
      Jinv[0][0] = J[1][1]/det;
      Jinv[0][1] =-J[0][1]/det;
      Jinv[1][0] =-J[1][0]/det;
      Jinv[1][1] = J[0][0]/det;
      for (j=0;j<2;j++) {
          dn[j] = alpha*(Jinv[j][0]*L[0]+Jinv[j][1]*L[1]);
          pt[j] = pt[j]-dn[j];
      }
      dm = sqrt(dn[0]*dn[0]+dn[1]*dn[1]);
      if (dm<epsl) break;
  }
  dist = get_C_Distance(p0,pt);
  if (ff(p0)<-1.0e-6)
     return -dist;
  else
     return dist;
}
                          

/**********************************************************/
/*Project the boundary nodes onto the curved boundary*/
/**********************************************************/
void proj_Curv_Boundary(double (*df)(double []),double pt[])
{
  double dd,ddx,ddy,ps[2],dgx,dgy;

  ps[0] = pt[0]-0.5*deps;
  ps[1] = pt[1];                                                                
  dd = df(ps);
  ps[0] = pt[0]+0.5*deps;
  ps[1] = pt[1];
  ddx = df(ps);
  dgx = (ddx-dd)/deps;
  ps[0] = pt[0]; 
  ps[1] = pt[1]-0.5*deps;
  dd = df(ps);
  ps[0] = pt[0];
  ps[1] = pt[1]+0.5*deps;
  ddy = df(ps);
  dgy = (ddy-dd)/deps;
  dd = df(pt);
  pt[0] = pt[0]-dd*dgx;
  pt[1] = pt[1]-dd*dgy;
}
