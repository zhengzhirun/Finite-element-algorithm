#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "assist.h"

#define PI 3.1415926535897932


/*********************************************************/
/*When the boundary of the domain contains only segments*/
/*********************************************************/

double df(double pt[])
{
  return 0.0;
} 


/*********************************************************/
/*When the boundary of the domain contains curves*/
/*********************************************************/

/*****Signed distance for circle.poly*****/
/*
double df(double pt[])
{
  double xc,yc,r,dd;

  xc = 0.0;
  yc = 0.0;
  r = 1.0;
  dd = dcircle(pt,xc,yc,r);
  
  return dd;
}
*/

/*****Signed distance for circ_in_circ.poly*****/
/*
double df(double pt[])
{
  double xc1,yc1,r1,xc2,yc2,r2,dd;
  
  xc1 = 0.0;
  yc1 = 0.0;
  r1 = 1.0;
  xc2 = 0.0;
  yc2 = 0.0;
  r2 = 0.5;
  dd = ddiff(dcircle(pt,xc1,yc1,r1),dcircle(pt,xc2,yc2,r2));

  return dd;
}
*/


/*****Signed distance for circ_in_squa.poly*****/
/*
double df(double pt[])
{
  int    n;
  double xc,yc,r,vx[4],vy[4],dd;
                                                                                
  xc = 0.0; yc = 0.0; r = 0.5;
  n = 4;
  vx[0]= -1.0; vy[0]= -1.0;
  vx[1]=  1.0; vy[1]= -1.0;
  vx[2]=  1.0; vy[2]=  1.0;
  vx[3]= -1.0; vy[3]=  1.0;
  dd = ddiff(dpoly(pt,vx,vy,n),dcircle(pt,xc,yc,r));
                                                                                
  return dd;
}
*/


/*****Signed distance for hexa_in_circ.poly*****/
/*
double df(double pt[])
{ 
  int    n;
  double xc,yc,r,vx[6],vy[6],dd;
  
  xc = 0.0; yc = 0.0; r = 1.0;
  n = 6;
  vx[0]= 0.4330126941; vy[0]= 0.2500000000;
  vx[1]= 0.0000000000; vy[1]= 0.5000000000;
  vx[2]=-0.4330126941; vy[2]= 0.2500000000;
  vx[3]=-0.4330126941; vy[3]= -0.2500000000;
  vx[4]= 0.0000000000; vy[4]= -0.5000000000;
  vx[5]= 0.4330126941; vy[5]= -0.2500000000;
  dd = ddiff(dcircle(pt,xc,yc,r),dpoly(pt,vx,vy,n));

  return dd;
}
*/


/*****Signed distance for 2half_circ.poly*****/
/*
double df(double pt[])
{
  double xc1,yc1,r1,xc2,yc2,r2,dd;
                                                  
  xc1 = 0.0; yc1 = 0.0; r1 = 1.0;
  xc2 = -0.4; yc2 = 0.0; r2 = 0.55;
  dd = ddiff(dcircle(pt,xc1,yc1,r1),dcircle(pt,xc2,yc2,r2));
  dd = dintersect(dd,-pt[1]);

  return dd;
}
*/


/*****Signed distance for composite.poly*****/
/*
double df(double pt[])
{
  double xc1,yc1,r1,xc2,yc2,r2,x0,y0,dd,lv[2],rv[2];
  double d1,d2,d3,d4,d5,theta,ps[2],ps1[2];
 
  xc1 = 0.0; yc1 = 0.0; r1 = 1.0;
  d1 = dcircle(pt,xc1,yc1,r1);
  theta = PI/12.0;
  lv[0] = -1.0; lv[1] = 0.0; rv[0] = 1.0; rv[1]= 1.0;
  protate(pt,theta,ps);
  d2 = drectangle(ps,lv,rv);
  lv[0] = -1.0; lv[1] = -1.0; rv[0] = 1.0; rv[1]= 0.0;
  protate(pt,-theta,ps);
  d3 = drectangle(ps,lv,rv);
  theta = PI/4.0;
  x0 = 0.9; y0 = 0.0;
  lv[0] = 0.0; lv[1] = 0.0; rv[0] = 0.2; rv[1]= 0.2;
  pshift(pt,x0,y0,ps1);
  protate(ps1,-theta,ps);
  d4 = drectangle(ps,lv,rv);
  xc2 = 0.6; yc2 = 0.0; r2 = 0.1;
  d5 = dcircle(pt,xc2,yc2,r2);
  dd = ddiff(ddiff(ddiff(ddiff(d1,d2),d3),d4),d5);
 
  return dd;
} 
*/



/**********************************************************/
/*Signed distance when implicit level set functions used*/
/**********************************************************/

/*****Signed distance for selipse.poly*****/
/*
double ff(double pt[])
{
  double func;
                                                                                
  func = pow(pow(pt[0],4.0)+pow(pt[1],4.0),0.25)-1.0;
                                                                                
  return func;
}
double df(double pt[])
{
  double dd;
                       
  dd = dlevel(ff,pt);
                                                                                
  return dd;
}
*/


/*****Signed distance for seli_in_seli.poly*****/
/*
double ff1(double pt[])
{
  double func;
                                                                                
  func = pow(pow(pt[0],4)+pow(pt[1],4),0.25)-1.0;
                                                                                
  return func;
}
double ff2(double pt[])
{
  double func;
                                                                                
  func = pow(pow(pt[0],4)+pow(pt[1],4),0.25)-0.5;
                                                                                
  return func;
}
double df(double pt[])
{
  double dd;
                                                               
  dd = ddiff(dlevel(ff1,pt),dlevel(ff2,pt));
       
  return dd;
}
*/


/*****Signed distance for PIshape.poly*****/
/*
double ff1(double pt[])
{
  double func;
                                                                                
  func = pt[1]-cos(pt[0]);
                                                                                
  return func;
}
double ff2(double pt[])
{
  double func;
                                                                                
  func = 5.0*pow((2.0*pt[0])/(5.0*PI),4.0)-5.0-pt[1];
                                                                                
  return func;
}
double df(double pt[])
{
  double dd;
                                                                                
  dd = dintersect(dlevel(ff1,pt),dlevel(ff2,pt));
                                                                                
  return dd;
}
*/
