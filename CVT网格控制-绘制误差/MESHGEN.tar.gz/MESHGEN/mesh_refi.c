#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <sys/types.h>
#include "ANN.h"

#include "assist.h"

#define max_neigh 36

typedef struct {
  int    ord;
  double crd[2],crd_n[2];
  int    mark;
  int    n_neigh_t;
  int    neigh_t[max_neigh];
} NODE;

typedef struct {
  int   ord;
  int   endpts[2];
  int   mark;
} EDGE;

typedef struct {
  int    ord;
  double crd[2];
} HOLE;

NODE   *nodes;
EDGE   *edges;
HOLE   *holes;
int    n_nodes,n_ref_nodes,n_trigs,n_holes,n_edges,n_b_edges,max_nodes;
int    ib,iu;
double *ed,pa;

void build_Kdtree();
  
double get_Density(double pt[]);

void free_Dens_Memory();

double df(double pt[]);


/*****Read the nodes information from "nodes.dat"*****/
void read_Nodes_From_File()
{
  FILE*  fp;
  double ftemp;
  int    i,j,ntemp;
  
  fp=fopen("nodes.dat","rt");
  fscanf(fp,"%d",&n_nodes);
  for (i=0;i<3;i++) fscanf(fp,"%d",&ntemp); 
  nodes = (NODE*)calloc(n_nodes,sizeof(NODE));
  for (i=0;i<n_nodes;i++) {
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%lf",&ftemp);
          (nodes+i)->crd[j] = ftemp;
      }
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->mark = ntemp;  
      (nodes+i)->n_neigh_t = 0; 
  }
  fclose(fp);   
}


/*****Read the triangles information from the input file "trigs.dat"*****/
void read_Trigs_From_File()
{
  FILE*  fp;

  fp=fopen("trigs.dat","rt");
  fscanf(fp,"%d",&n_trigs);
  fclose(fp);
}


/*****Read the edges information from "edges.dat"*****/
void read_Edges_From_File()
{
  FILE*  fp;
  int    i,j,ntemp,p0,p1;
  
  fp=fopen("edges.dat","rt");
  fscanf(fp,"%d",&n_edges);
  fscanf(fp,"%d",&ntemp); 
  edges = (EDGE*)calloc(n_edges,sizeof(EDGE));
  for (i=0;i<n_edges;i++) {
      (edges+i)->mark = 0;
      fscanf(fp,"%d",&ntemp);
      (edges+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%d",&ntemp);
          (edges+i)->endpts[j] = ntemp-1;
      }
      fscanf(fp,"%d",&ntemp);
      (edges+i)->mark = ntemp;
  }
  fclose(fp);   
}


/*****Read the segments and holes information from "polys.dat"*****/
void read_Polys_From_File()
{
  FILE*  fp;
  double ftemp;
  int    i,j,ntemp;
                             
  fp=fopen("polys.dat","rt");
  for (i=0;i<4;i++) fscanf(fp,"%d",&ntemp);
  fscanf(fp,"%d",&n_b_edges);
  fscanf(fp,"%d",&ntemp);
  for (i=0;i<n_b_edges;i++) {
      fscanf(fp,"%d",&ntemp);
      for (j=0;j<2;j++) fscanf(fp,"%d",&ntemp);
      fscanf(fp,"%d",&ntemp);
  }
  fscanf(fp,"%d",&n_holes);
  holes = (HOLE*)calloc(n_holes,sizeof(HOLE));
  for (i=0;i<n_holes;i++) {
      fscanf(fp,"%d",&ntemp);
      (holes+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%lf",&ftemp);
          (holes+i)->crd[j] = ftemp;
      }
  }
  fclose(fp);
}


int compare_Eng(const void* v1,const void* v2)
{
  int i1 = *((int*)v1),i2 = *((int*)v2);

  if (ed[i1]>ed[i2])
     return 1;
  else if (ed[i1]<ed[i2])     
     return -1;
  else
     return 0;
}


/*****Add the middle points of each edge into the mesh and write
      the "inter.node" and "inter.poly" for retriangulation*****/  
void add_Mid_Points()
{ 
  FILE*  fp;
  double ftemp,rt,ps,*dend,pmin,pmax,psum,qs;
  int    i,j,k,*pt,*q,p0,p1,nbedge,ne,*pd,ii;
  long   Mr;
  time_t t1;
  
  /***Initialize Kdtree for the density function defined by backgroud nodes***/
  if (ib==1) build_Kdtree();
  pt = (int*)calloc(n_edges,sizeof(int));
  q = (int*)calloc(n_edges,sizeof(int));
  if (iu==1) {
     /*The number of points of refined mesh is bounded above by max_nodes*/
     if ((n_nodes+n_edges)<max_nodes) { 
        n_ref_nodes = n_nodes+n_edges;
        ne = n_edges;
     }
     else { 
        n_ref_nodes = max_nodes;
        ne = max_nodes-n_nodes;
     }
     ps = (1.0*ne)/n_edges;
     if (ne==n_edges) {
        for (i=0;i<n_edges;i++) q[i] = 1;
     }
     else { 
        Mr = 1;
        for (i=0;i<31;i++) Mr = Mr*2;
        Mr = Mr-1;
        (void) time(&t1);  
        srand48((long) t1);
        k = 0;
        for (i=0;i<n_edges;i++) q[i] = 0;
        while (k<ne) {
           for (i=0;i<n_edges;i++) {
               if (q[i]==0) {
                  rt = (1.0*lrand48())/Mr;
                  if (rt<ps) {
                     q[i] = 1;
                     k = k+1;  
                  }
               }
               if (k==ne) break;
           }
        } 
     }
  }
  else {
     pd = (int*)calloc(n_edges,sizeof(int));
     pmin = 1.0e15;
     pmax = 0.0;
     psum = 0.0;
     dend = (double*)calloc(n_nodes,sizeof(double));
     for (i=0;i<n_nodes;i++) dend[i] = get_Density((nodes+i)->crd);
     ed = (double*)calloc(n_edges,sizeof(double));
     for (i=0;i<n_edges;i++) {
         pd[i] = i;
         p0 = (edges+i)->endpts[0];
         p1 = (edges+i)->endpts[1];
         ed[i] = 0.5*(dend[p0]+dend[p1]);   
         ed[i] = pow(ed[i],0.5)
             *pow(get_C_Distance((nodes+p0)->crd,(nodes+p1)->crd),2.0);
         if (ed[i]>pmax) pmax = ed[i];
         if (ed[i]<pmin) pmin = ed[i];
         psum += ed[i];
     }
     qsort(pd,n_edges,sizeof(int),compare_Eng);
     n_ref_nodes = n_nodes;
     qs = 0.0;
     for (i=0;i<n_edges;i++) {
         ii = pd[n_edges-1-i];
         q[ii] = 0;
         qs += ed[ii];
         if (qs<pa*psum) {
            q[ii] = 1;
            n_ref_nodes ++;
            if (n_ref_nodes==max_nodes) break;
         } 
         /*
         q[i] = 0;
         if ((ed[i]-pmin)/(pmax-pmin)>(pa-1.0e-4)) {
            q[i] = 1;
            n_ref_nodes ++;
         }
         */
     }
     ne = n_ref_nodes-n_nodes;
  }
  /***Write the "inter.dat"***/
  fp=fopen("inter.node","wt");
  fprintf(fp,"%10d  2  0  1\n", n_ref_nodes);
  for (i=0;i<n_nodes;i++) {
      fprintf(fp,"%10d  ", i+1);
      for (j=0;j<2;j++)
          fprintf(fp,"%.10f  ",(nodes+i)->crd[j]);
      fprintf(fp,"%10d\n",(nodes+i)->mark);
  }
  nbedge = 0;
  k = 0;
  for (i=0;i<n_edges;i++) {
      pt[i] = 0;
      if (((edges+i)->mark>1)||((edges+i)->mark<-1)) nbedge = nbedge+1;
      if (q[i]==1) {
         pt[i] = n_nodes+k;
         fprintf(fp,"%10d  ", n_nodes+k+1);
         k = k+1;
         p0 = (edges+i)->endpts[0];
         p1 = (edges+i)->endpts[1];
         for (j=0;j<2;j++) {
	     ftemp = 0.5*((nodes+p0)->crd[j]+(nodes+p1)->crd[j]);
             fprintf(fp,"%.10f  ",ftemp);
         }
         fprintf(fp,"%10d\n",(edges+i)->mark);
         if (((edges+i)->mark>1)||((edges+i)->mark<-1)) nbedge = nbedge+1;
      }
  }
  fclose(fp);
  /***Write the "inter.poly"***/
  fp=fopen("inter.poly","wt");
  fprintf(fp, "0  2  0  1\n");
  fprintf(fp,"%10d  ", nbedge);
  fprintf(fp,"1\n");
  k = 1;
  for (i=0;i<n_edges;i++) {
      p0 = (edges+i)->endpts[0];
      p1 = (edges+i)->endpts[1];
      if ((((edges+i)->mark>1)||((edges+i)->mark<-1))&&(q[i]==1)) {
         fprintf(fp,"%10d  ", k);
         fprintf(fp,"%10d  ", p0+1);
         fprintf(fp,"%10d  ", pt[i]+1);
         fprintf(fp,"%10d\n", (edges+i)->mark);
         k = k+1;
         fprintf(fp,"%10d  ", k);
         fprintf(fp,"%10d  ", p1+1);
         fprintf(fp,"%10d  ", pt[i]+1);
         fprintf(fp,"%10d\n", (edges+i)->mark);
         k = k+1;
      }   
      if ((((edges+i)->mark>1)||((edges+i)->mark<-1))&&(q[i]==0)) {
         fprintf(fp,"%10d  ", k);
         fprintf(fp,"%10d  ", p0+1);
         fprintf(fp,"%10d  ", p1+1);
         fprintf(fp,"%10d\n", (edges+i)->mark);
         k = k+1;
      }
  }  
  fprintf(fp, "%10d\n",n_holes);
  for (i=0;i<n_holes;i++) {
      fprintf(fp,"%10d  ", ((holes+i)->ord)+1);
      for (j=0;j<2;j++)
          fprintf(fp,"%.10f  ", (holes+i)->crd[j]);
      fprintf(fp,"\n");
  }
  fclose(fp);
}



int main(int argc,char **argv)
{
  int i,kk,it,A[4];

  max_nodes = 10000000;
  iu = 0;
  ib = 0;
  pa = 0.5;
  if ((argc-1)%2!=0) {
      printf("Command options error!\n");
      exit(0);
  }
  kk = (int)((argc-1)/2);
  /***Read command options***/
  for (i=0;i<kk;i++) {
      it = 0;
      if (strcmp(argv[2*i+1],"-n")==0) {
         max_nodes = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-u")==0) {
         iu = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-p")==0) {
         pa = atof(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-b")==0) {
         ib = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (it==0) {
         printf("Command options error!\n");
         exit(0);
      }
  }
  read_Nodes_From_File();
  if (max_nodes<=n_nodes) {
     printf("There already are enough nodes.\n");
     exit(0);
  }
  read_Trigs_From_File();
  printf("******Before Refinement******\n");
  printf("# of Nodes     = %10d\n",n_nodes);
  printf("# of Triangles = %10d\n",n_trigs);
  read_Edges_From_File();
  read_Polys_From_File();
  add_Mid_Points();
  system("./triangle -pneQ inter.poly");
  wait(NULL);
  system("cp inter.1.ele trigs.dat");
  wait(NULL);
  system("cp inter.1.node nodes.dat");
  wait(NULL);
  system("cp inter.1.poly polys.dat");
  wait(NULL);
  system("cp inter.1.edge edges.dat");
  wait(NULL);
  system("cp inter.1.neigh neigs.dat");
  wait(NULL);
  read_Trigs_From_File();
  printf("******After Refinement******\n");
  printf("# of Nodes     = %10d\n",n_ref_nodes);
  printf("# of Triangles = %10d\n",n_trigs);
  free(nodes);
  free(edges);
  free(holes);
}
