#include <stdio.h>  
#include <stdlib.h>
#include <math.h> 
#include <string.h>

typedef struct {
  int    ord;
  double pl_crd[2];
  double sp_crd[3];
  double density;
  int    mark;
} NODE;

NODE   *nodes;
int    n_nodes,n_trigs,n_bd_nodes;
double *bd_nodes_crd;
double radi = 6371000;


/*****Density fuction*****/
double get_Bd_Dist(double pt[])
{
  double dist,dd;
  int    i;
   
  dist = 1.0e15;
  for (i=0;i<n_bd_nodes;i++) {
      dd = sqrt((bd_nodes_crd[3*i]-pt[0])*(bd_nodes_crd[3*i]-pt[0])+(bd_nodes_crd[3*i+1]-pt[1])
              *(bd_nodes_crd[3*i+1]-pt[1])+(bd_nodes_crd[3*i+2]-pt[2])*(bd_nodes_crd[3*i+2]-pt[2]));
      if ((dd<dist)&&(dd>0)) dist = dd;
  }
  return dist;
}


/*****Read the nodes information from the input file "nodes.dat"*****/
void read_Nodes_From_File()
{
  FILE*  fp;
  double ftemp,x,y,xy2;
  int    i,j,ntemp,nn;
                         
  fp = fopen("nodes.dat","rt");
  fscanf(fp,"%d ",&n_nodes);
  for (i=0;i<3;i++) fscanf(fp,"%d",&ntemp);
  nodes = (NODE*)calloc(n_nodes,sizeof(NODE));
  n_bd_nodes = 0;
  for (i=0;i<n_nodes;i++) {
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%lf",&ftemp);
          (nodes+i)->pl_crd[j] = ftemp;
      }
      x = 0.5*(nodes+i)->pl_crd[0]/radi;
      y = 0.5*(nodes+i)->pl_crd[1]/radi;
      xy2 = x*x+y*y;
      (nodes+i)->sp_crd[0] = radi*2*x/(1+xy2);
      (nodes+i)->sp_crd[1] = radi*2*y/(1+xy2);
      (nodes+i)->sp_crd[2] = radi*(1-xy2)/(1+xy2);
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->mark = ntemp;
      if (ntemp>0) n_bd_nodes ++;
  }
  fclose(fp);
  bd_nodes_crd = (double*)calloc(3*n_bd_nodes,sizeof(double));
  nn = 0;
  for (i=0;i<n_nodes;i++) {
      if ((nodes+i)->mark>0) {
         for (j=0;j<3;j++)  bd_nodes_crd[3*nn+j] = (nodes+i)->sp_crd[j];
         nn ++;
      }
  }       
}


/*****Write the density information files for density function*****/
void write_Dens_Info()
{
  FILE*  fp;
  int    i,j;
  double denmin,denmax,denvar,fd,reqden,meshvar,scale;
              
  fp = fopen("dens_nodes.dat","wt");
  denmax = -1.0e15;
  denmin = 1.0e15; 
  for (i=0;i<n_nodes;i++) {
      (nodes+i)->density = 1.0/pow(get_Bd_Dist((nodes+i)->sp_crd)+10000.0,2.0);
      if ((nodes+i)->density>denmax) denmax = (nodes+i)->density;
      if ((nodes+i)->density<denmin) denmin = (nodes+i)->density; 
      for (j=0;j<3;j++) fprintf(fp,"%.12f  ",(nodes+i)->sp_crd[j]);
      fprintf(fp," \n");
  }
  fclose(fp);
  denvar = denmax/denmin;
  meshvar = 100.0;
  reqden = pow(meshvar,4.0);
  fp = fopen("dens_valus.dat","wt");
  for (i=0;i<n_nodes;i++) { 
      scale = 4*radi*radi/(4*radi*radi+(nodes+i)->pl_crd[0]*(nodes+i)->pl_crd[0]+
              (nodes+i)->pl_crd[1]*(nodes+i)->pl_crd[1]);
      fd = fmax((nodes+i)->density/denmax,1.0/reqden)*radi*pow(scale,4.0);
      fprintf(fp,"%.12f ",fd);
      fprintf(fp,"\n");
  }
  fclose(fp);
}


int main()
{
  read_Nodes_From_File();
  printf("# of background nodes = %10d\n",n_nodes);
  printf("Generate dens_nodes.dat and dens_valus.dat ...\n");
  write_Dens_Info();
}
