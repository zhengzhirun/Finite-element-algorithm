#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <sys/types.h>

#include "assist.h"

#define max_neigh 36

typedef struct {
  int    ord;
  double crd[2],crd_n[2];
  int    mark;
  int    n_neigh_t;
  int    neigh_t[max_neigh];
} NODE;
                                                                                
typedef struct {
  int   ord;
  int   endpts[2];
  int   mark;
} EDGE;
                                                                                
typedef struct {
  int    ord;
  double crd[2];
} HOLE;
                                                                                
NODE   *nodes;
EDGE   *edges;
HOLE   *holes;
int    n_nodes,n_ref_nodes,n_holes,n_edges,n_b_edges,max_nodes;

int   ip,ic,iq;
char  ar[10];

void build_Kdtree();

double get_Density(double pt[]);

void free_Dens_Memory();

double df(double pt[]);


/*****Read the nodes information from "nodes.dat"*****/  
void read_Nodes_From_File()
{
  FILE*  fp;
  double ftemp;
  int    i,j,ntemp;
                                                                                
  fp=fopen("nodes.dat","rt");
  fscanf(fp,"%d",&n_nodes);
  for (i=0;i<3;i++) fscanf(fp,"%d",&ntemp);
  nodes = (NODE*)calloc(n_nodes,sizeof(NODE));
  for (i=0;i<n_nodes;i++) {
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%lf",&ftemp);
          (nodes+i)->crd[j] = ftemp;
      }
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->mark = ntemp;
      (nodes+i)->n_neigh_t = 0;
      if (ic!=0)
         if ((nodes+i)->mark>1)
                   proj_Curv_Boundary(df,(nodes+i)->crd);
  }
  fclose(fp);
}


/*****Read the edges information from "edges.dat"*****/  
void read_Edges_From_File()
{
  FILE*  fp;
  int    i,j,ntemp,p0,p1;
                                                                                
  fp=fopen("edges.dat","rt");
  fscanf(fp,"%d",&n_edges);
  fscanf(fp,"%d",&ntemp);
  edges = (EDGE*)calloc(n_edges,sizeof(EDGE));
  for (i=0;i<n_edges;i++) {
      (edges+i)->mark = 0;
      fscanf(fp,"%d",&ntemp);
      (edges+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%d",&ntemp);
          (edges+i)->endpts[j] = ntemp-1;
      }
      fscanf(fp,"%d",&ntemp);
      (edges+i)->mark = ntemp;
  }
  fclose(fp);
}


/*****Read the segments and holes information from "polys.dat"*****/  
void read_Polys_From_File()
{
  FILE*   fp;
  double  ftemp;
  int     i,j,ntemp;
                                                                               
  fp=fopen("polys.dat","rt");
  for (i=0;i<4;i++) fscanf(fp,"%d",&ntemp);
  fscanf(fp,"%d",&n_b_edges);
  fscanf(fp,"%d",&ntemp);
  for (i=0;i<n_b_edges;i++) {
      fscanf(fp,"%d",&ntemp);
      for (j=0;j<2;j++) fscanf(fp,"%d",&ntemp);
      fscanf(fp,"%d",&ntemp);
  }
  fscanf(fp,"%d",&n_holes);
  holes = (HOLE*)calloc(n_holes,sizeof(HOLE));
  for (i=0;i<n_holes;i++) {
      fscanf(fp,"%d",&ntemp);
      (holes+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%lf",&ftemp);
          (holes+i)->crd[j] = ftemp;
      }
  }
  fclose(fp);
}


/*****Add points on edges according to the density fuction into 
      the mesh and write "middle.node" and "middle.poly" for
      retriangulation*****/
void add_Points_With_Density(int ne)
{
  FILE*   fp;
  double  rt,*ps,pp[2],prob_m,alp,ftmp[2];
  int     i,j,k,m,*pt,*q,p0,p1,nbedge;
  long    Mr;
  time_t  t1;
                                           
  n_ref_nodes = ne+n_nodes;
  pt = (int*)calloc(n_edges,sizeof(int));
  q = (int*)calloc(n_edges,sizeof(int));
  ps = (double*)calloc(n_edges,sizeof(double));
  prob_m = 0.0;
  for (i=0;i<n_edges;i++) {
      p0 = (edges+i)->endpts[0];
      p1 = (edges+i)->endpts[1];
      for (j=0;j<2;j++) 
              pp[j] = 0.5*((nodes+p0)->crd[j]+(nodes+p1)->crd[j]);
      if (ne==0)
         ps[i] = 1.0;
      else
         ps[i] = get_Density(pp);
      prob_m = fmax(ps[i],prob_m);
  }
  /***Normalize the density***/
  for (i=0;i<n_edges;i++) ps[i] = ps[i]/prob_m;
  /***Write the file "middle.node" with new points***/ 
  fp=fopen("middle.node","wt");
  fprintf(fp,"%10d  2  0  1\n", n_ref_nodes);
  for (i=0;i<n_nodes;i++) {
      fprintf(fp,"%10d  ", i+1);
      for (j=0;j<2;j++)
          fprintf(fp,"%.10f  ",(nodes+i)->crd[j]);
      fprintf(fp,"%10d\n",(nodes+i)->mark);
  }
  Mr = 1;
  for (i=0;i<31;i++) Mr = Mr*2;
  Mr = Mr-1;
  (void) time(&t1);
  srand48((long) t1);
  k = 0;
  for (i=0;i<n_edges;i++) q[i] = 0;
  while (k<ne) {
      rt = (1.0*lrand48())/Mr;      
      i = (int)(rt*n_edges);
      rt = (1.0*lrand48())/Mr;
      if ((rt<ps[i])&&(q[i]<3)) {
         q[i] = q[i]+1;
         k = k+1;
      }
  } 
  nbedge = 0;
  k = 0;
  for (i=0;i<n_edges;i++) {
      pt[i] = 0;
      if ((edges+i)->mark>1) nbedge = nbedge+1;
      if (q[i]>=1) {
         pt[i] = n_nodes+k;
         p0 = (edges+i)->endpts[0];
         p1 = (edges+i)->endpts[1];
         for (m=0;m<q[i];m++) {
             alp = (1.0*m+1.0)/(q[i]+1.0);
             fprintf(fp,"%10d  ", n_nodes+k+1+m);
             for (j=0;j<2;j++) 
                 ftmp[j] = (1.0-alp)*(nodes+p0)->crd[j]
                         +alp*(nodes+p1)->crd[j];
             if (ic!=0)
                if ((edges+i)->mark>2)
                   proj_Curv_Boundary(df,ftmp);
             fprintf(fp,"%.10f  %.10f  ",ftmp[0],ftmp[1]);
             fprintf(fp,"%10d\n",(edges+i)->mark);
         }
         k = k+q[i];
         if ((edges+i)->mark>1) nbedge = nbedge+q[i];
      }
  }
  fclose(fp);
  /***Write the file "middle.poly" with new segments***/
  fp=fopen("middle.poly","wt");
  fprintf(fp, "0  2  0  1\n");
  fprintf(fp,"%10d  ", nbedge);
  fprintf(fp,"1\n");
  k = 1;
  for (i=0;i<n_edges;i++) {
      p0 = (edges+i)->endpts[0];
      p1 = (edges+i)->endpts[1];
      if (((edges+i)->mark>1)&&(q[i]>=1)) {
         fprintf(fp,"%10d  ", k);
         fprintf(fp,"%10d  ", p0+1);
         fprintf(fp,"%10d  ", pt[i]+1);
         fprintf(fp,"%10d\n", (edges+i)->mark);
         k = k+1;
         for (m=0;m<q[i]-1;m++) {
             fprintf(fp,"%10d  ", k);
             fprintf(fp,"%10d  ", pt[i]+1+m);
             fprintf(fp,"%10d  ", pt[i]+2+m);
             fprintf(fp,"%3d\n", (edges+i)->mark);
             k = k+1;
         }
         fprintf(fp,"%10d  ", k);
         fprintf(fp,"%10d  ", pt[i]+q[i]);
         fprintf(fp,"%10d  ", p1+1);
         fprintf(fp,"%10d\n", (edges+i)->mark);
         k = k+1;
      }
      if (((edges+i)->mark>1)&&(q[i]==0)) {
         fprintf(fp,"%10d  ", k);
         fprintf(fp,"%10d  ", p0+1);
         fprintf(fp,"%10d  ", p1+1);
         fprintf(fp,"%10d\n", (edges+i)->mark);
         k = k+1;
      }
  }
  fprintf(fp, "%10d\n",n_holes);
  for (i=0;i<n_holes;i++) {
      fprintf(fp,"%10d  ", ((holes+i)->ord)+1);
      for (j=0;j<2;j++)
          fprintf(fp,"%.10f  ", (holes+i)->crd[j]);
      fprintf(fp,"\n");
  }
  fclose(fp);
}



int main(int argc,char **argv)
{
  int    i,kk,ib,it,idc,a_nodes;
  char   s1[50]="./triangle ",s2[20],s3[12]=" input.poly";
  char   name[30],cp1[50]="cp ";
  double p0[2];

  ip = 0;
  strcpy(ar,"0.01");
  ic = 0;
  iq = 0;
  ib = 0;
  if ((argc-1)%2!=0) {
      printf("Command options error!\n");
      exit(0);
  }
  idc = 0;
  kk = (int)((argc-1)/2);
  /***Read command options***/
  for (i=0;i<kk;i++) {
      it = 0;
      if (strcmp(argv[2*i+1],"-d")==0) {
         ip = atoi(argv[2*(i+1)]);
         it = 1;
      } 
      if (strcmp(argv[2*i+1],"-a")==0) {
          strcpy(ar,argv[2*(i+1)]); 
          it = 1;
      }
      if (strcmp(argv[2*i+1],"-c")==0) {
         ic = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-q")==0) {
         iq = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-f")==0) {
         strcpy(name,argv[2*(i+1)]);
         it = 1;
         idc = 1;
      }
      if (strcmp(argv[2*i+1],"-b")==0) {
         ib = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (it==0) {
         printf("Command options error!\n");
         exit(0);
      } 
  }
  /***Initialize Kdtree for the density function defined by backgroud nodes***/
  if (ib==1) build_Kdtree();
  if (idc==1) {
     strcat(cp1,name);
     strcat(cp1,s3);
     system(cp1);
     wait(NULL);
  }
  /***If the quality control is used***/
  if (iq==0) 
     strcpy(s2,"-pne");
  else {
     strcpy(s2,"-pqne-a");
     strcat(s2,ar);
  }
  /*if ((ip!=0)||(ic!=0)) strcat(s2,"Q");*/
  strcat(s1,s2);
  strcat(s1,s3);
  system(s1);
  wait(NULL);
  /***If adding points with density or the boundary is curved***/ 
  if ((ip!=0)||(ic!=0)) {
     system("cp input.1.ele trigs.dat");
     wait(NULL);
     system("cp input.1.node nodes.dat");
     wait(NULL);
     system("cp input.1.poly polys.dat");
     wait(NULL);
     system("cp input.1.edge edges.dat");
     wait(NULL);
     system("cp input.1.neigh neigs.dat");
     wait(NULL);
     read_Nodes_From_File();
     read_Edges_From_File();
     read_Polys_From_File();
     if (ip!=0)
        a_nodes = n_nodes;
     else
        a_nodes = 0;
     add_Points_With_Density(a_nodes);
     if (ip!=0) {
        printf("/**********************************************************/\n");
        printf("Add %10d nodes randomly according to density function\n",a_nodes);
        printf("/**********************************************************/\n\n");
        system("./triangle -pne middle.poly");
     }
     else
        system("./triangle -pneQ middle.poly"); 
     wait(NULL);
     system("cp middle.1.ele input.1.ele");
     wait(NULL);
     system("cp middle.1.node input.1.node");
     wait(NULL);
     system("cp middle.1.poly input.1.poly");
     wait(NULL);
     system("cp middle.1.edge input.1.edge");
     wait(NULL);
     system("cp middle.1.neigh input.1.neigh");
     wait(NULL);
     system("rm middle.*");
     wait(NULL); 
  }
  system("cp input.1.ele trigs.dat");
  wait(NULL);
  system("cp input.1.node nodes.dat");
  wait(NULL);
  system("cp input.1.poly polys.dat");
  wait(NULL);
  system("cp input.1.edge edges.dat");
  wait(NULL);
  system("cp input.1.neigh neigs.dat");
  wait(NULL);
  if (ib==1) free_Dens_Memory();
}
