#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>

#include "assist.h"

#define REAL double
#include "triangle.h"

#define max_neigh 36
#define PI 3.1415926535897932
#define ang_min 30
#define ang_max 101
#define ang_int_min 45
#define ipt 5
#define irt 7
#define ijump 200
#define maxintv 10

typedef struct {
  int    ord;
  double crd[2],crd_n[2];
  int    mark;
  int    n_neigh_t;
  int    neigh_t[max_neigh];
  double ang_f_b;
  int    f_b_mark;
  int    p_f_b[2];
  int    pmark;
  int    n_b;
  int    b_neigh[10];
  int    b_mark[10];
  int    p_m;
  int    vsa;
  double den;
} NODE;

typedef struct {
  int    ord;
  int    vtx[3];
  int    mark;
  double area;
  double center[2];
  double circenter[2];
  double circumR;
  double R;
  double ang[3];
  double den;
  double h,q,eng;
} TRIG;

typedef struct {
  int   ord;
  int   endpts[2];
  int   mark;
} EDGE;

typedef struct {
  int    ord;
  double crd[2];
} HOLE;

NODE   *nodes;
TRIG   *trigs;
EDGE   *b_edges;
HOLE   *holes;
int    n_nodes,n_trigs,n_b_edges,n_holes,max_iter,ic,iv;
double d_move,eps,T_area;
int    *p_p,*p_r,*r_r,topo_ch;

struct triangulateio  in,out;

void build_Kdtree();

double get_Density(double pt[]);

void free_Dens_Memory();

double df(double pt[]);


/*****Compute the distance between two nodes v0 and v1*****/
double get_Distance(int v0, int v1)
{
  double dist,tt;
  int    i;
                     
  dist = 0.0;    
  for (i=0;i<2;i++) {
      tt = (nodes+v0)->crd[i]-(nodes+v1)->crd[i];
      dist += tt*tt; 
  }
                            
  return sqrt(dist);
}


/*****Compute the area of the triangle (v0,v1,v2)*****/
double get_Area(int v0,int v1,int v2)
{
  double area,a[2],b[2];
  int    i;

  for (i=0;i<2;i++) {
      a[i]=(nodes+v1)->crd[i]-(nodes+v0)->crd[i];
      b[i]=(nodes+v2)->crd[i]-(nodes+v0)->crd[i];
  }
  area = a[0]*b[1]-a[1]*b[0];
  if (area>=0) 
     area = 0.5*area;
  else
     area = -0.5*area;      

  return area;
}


/*****Compute the radius of the triangle (v0,v1,v2)*****/
double get_Radius(int v0,int v1,int v2)
{
  double e1,e2,e3;
                                                                                              
  e1 = get_Distance(v0,v1);
  e2 = get_Distance(v1,v2);
  e3 = get_Distance(v2,v0);
                                                                                              
  return 0.5*fmax(fmax(e1,e2),e3);
}


/*****Compute the circumradius of the triangle (v0,v1,v2)*****/
double get_CircumRadius(int v0,int v1,int v2,double circenter[2])
{
  int    i;
  double A[2],B[2],C[2],A2,B2,C2,a,b,S[2],s1,s2;

  for (i=0;i<2;i++) {
      A[i]=(nodes+v0)->crd[i];
      B[i]=(nodes+v1)->crd[i];
      C[i]=(nodes+v2)->crd[i];
  }
  A2 = A[0]*A[0]+A[1]*A[1];
  B2 = B[0]*B[0]+B[1]*B[1];
  C2 = C[0]*C[0]+C[1]*C[1];
  a = (B[0]*C[1]-B[1]*C[0])-(A[0]*C[1]-A[1]*C[0])
      +(A[0]*B[1]-A[1]*B[0]);
  b = A2*(B[0]*C[1]-B[1]*C[0])-B2*(A[0]*C[1]-A[1]*C[0])
      +C2*(A[0]*B[1]-A[1]*B[0]);
  S[0] = 0.5*((B2*C[1]-B[1]*C2)-(A2*C[1]-A[1]*C2)
         +(A2*B[1]-A[1]*B2));
  S[1] = 0.5*((B[0]*C2-B2*C[0])-(A[0]*C2-A2*C[0])
         +(A[0]*B2-A2*B[0]));
  s1 = circenter[0] = S[0]/a;
  s2 = circenter[1] = S[1]/a;
  
  return sqrt(b/a+s1*s1+s2*s2);
}


/*****Compute the quality measure Q of the triangle (v0,v1,v2)*****/
double get_Q(int v0,int v1,int v2)
{
  double d0,d1,d2,q;
  
  d0 = get_Distance(v1,v2);
  d1 = get_Distance(v2,v0);
  d2 = get_Distance(v0,v1);
  q = ((d0+d1-d2)/d2)*((d1+d2-d0)/d0)*((d2+d0-d1)/d1);

  return q;
}


/*****Compute all angles of the triangle (v0,v1,v2)*****/
void get_Trig_Angles(int v0,int v1,int v2,double ang[])
{
  double ds[3];
  int    i;

  ds[0] = get_Distance(v1,v2);
  ds[1] = get_Distance(v2,v0);
  ds[2] = get_Distance(v0,v1);
  ang[0] = a_cos((ds[1]*ds[1]+ds[2]*ds[2]-ds[0]*ds[0])
           /(2.0*ds[1]*ds[2]));
  ang[1] = a_cos((ds[2]*ds[2]+ds[0]*ds[0]-ds[1]*ds[1])
           /(2.0*ds[2]*ds[0]));
  ang[2] = a_cos((ds[0]*ds[0]+ds[1]*ds[1]-ds[2]*ds[2])
           /(2.0*ds[0]*ds[1]));
  for (i=0;i<3;i++) ang[i] = ang[i]*180/PI;
}


/*****Compute the angle <v1_v0_v2>*****/
double get_Angle(int v0,int v1,int v2)
{
  double ds[3],ang;
  int    i;
                                                                                
  ds[0] = get_Distance(v1,v2);
  ds[1] = get_Distance(v2,v0);
  ds[2] = get_Distance(v0,v1);
  ang = a_cos((ds[1]*ds[1]+ds[2]*ds[2]-ds[0]*ds[0])
           /(2.0*ds[1]*ds[2]));
  
  return ang*180/PI;
}


/*****Find the mark of the boundary edge (v0,v1)*****/
int check_Boundary(int v0,int v1)
{
  int  i,ibd,pv;
              
  ibd = 0;
  for (i=0;i<(nodes+v0)->n_b;i++) {
      pv = (nodes+v0)->b_neigh[i];
      if (pv==v1) {
         ibd = (nodes+v0)->b_mark[i];
         break;
      }
  }
  
  return ibd;
}


/*****Find the mark of the boundary edge and the corresponding angle
      faced by the node "nv" if it is an interior node (i.e. its mark 
      equals 0; otherwise, find its two neighbor boundary nodes
*****/
void init_Node_F_B(int nv)
{
  double theta,rt;
  int    i,j,k,lt,nt,v0,v1,v2,mark0,mark1,mark2,sv[2];
  long   Mr;
  time_t t1;

  Mr = 1;
  for (i=0;i<31;i++) Mr = Mr*2;
  Mr = Mr-1;
  (void) time(&t1);
  srand48((long) t1);     
  (nodes+nv)->ang_f_b = 0.0;
  (nodes+nv)->f_b_mark = 0;
  lt = (nodes+nv)->n_neigh_t;        
  if ((nodes+nv)->mark==0) {
     for (i=0;i<lt;i++) {
         nt = (nodes+nv)->neigh_t[i];
         if ((trigs+nt)->mark>1) {
            v0 = nv;
            for (j=0;j<3;j++) {
                if ((trigs+nt)->vtx[j]==nv) {
                   v1 = (trigs+nt)->vtx[(j+1)%3];
                   v2 = (trigs+nt)->vtx[(j+2)%3];
                   mark0 = check_Boundary(v1,v2);
                   if (mark0!=0) {
                      theta = get_Angle(v0,v1,v2);
                      if (theta>(nodes+nv)->ang_f_b) {
                         (nodes+nv)->ang_f_b = theta;
                         (nodes+nv)->p_f_b[0] = v1;
                         (nodes+nv)->p_f_b[1] = v2;
                         (nodes+nv)->f_b_mark = mark0;
                      }
                   }
                   break;
                }
            }
         }
     }
  } 
  else if ((nodes+nv)->mark>1) {
     for (i=0;i<lt;i++) {
         nt = (nodes+nv)->neigh_t[i];
         if ((trigs+nt)->mark>1) {
            v0 = nv;
            for (j=0;j<3;j++) {
                if ((trigs+nt)->vtx[j]==nv) {
                   v1 = (trigs+nt)->vtx[(j+1)%3];
                   v2 = (trigs+nt)->vtx[(j+2)%3];
                   mark1 = (nodes+v1)->mark;
                   if (mark1!=0) {
                      mark0 = check_Boundary(v1,v0);
                      if (mark0>2) {
                         theta = get_Angle(v2,v1,v0);
                         if (theta>(nodes+nv)->ang_f_b)
                                 (nodes+nv)->ang_f_b = theta;
                         (nodes+nv)->p_f_b[0] = v1;
                      }
                   }
                   mark2 = (nodes+v2)->mark;
                   if (mark2!=0) {
                      mark0 = check_Boundary(v2,v0);
                      if (mark0>2) {
                         theta = get_Angle(v1,v2,v0);
                         if (theta>(nodes+nv)->ang_f_b)
                                 (nodes+nv)->ang_f_b = theta;
                         (nodes+nv)->p_f_b[1] = v2;
                      }
                   }
                   break;
                }
            }
         }
     }
  }
  else if ((nodes+nv)->mark<-1) {
     (nodes+nv)->p_f_b[0] = (nodes+nv)->p_f_b[1] = 0;
     for (i=0;i<lt;i++) {
         nt = (nodes+nv)->neigh_t[i];
         if ((trigs+nt)->mark>1) {
            v0 = nv;
            for (j=0;j<3;j++) {
                if ((trigs+nt)->vtx[j]==nv) {
                   v1 = (trigs+nt)->vtx[(j+1)%3];
                   v2 = (trigs+nt)->vtx[(j+2)%3];
                   mark1 = (nodes+v1)->mark;
                   if (mark1!=0) {
                      mark0 = check_Boundary(v1,v0);
                      if (mark0<-2) {
                         if (((nodes+nv)->p_f_b[0]==0)&&
                               (v1!=(nodes+nv)->p_f_b[1])) {
                            theta = get_Angle(v2,v1,v0);
                            if (theta>(nodes+nv)->ang_f_b) 
                                 (nodes+nv)->ang_f_b = theta;
                            sv[0] = v2;
                            (nodes+nv)->p_f_b[0] = v1;
                         }
                      }
                   }
                   mark2 = (nodes+v2)->mark;
                   if (mark2!=0) {
                      mark0 = check_Boundary(v2,v0);
                      if (mark0<-2) {
                         if (((nodes+nv)->p_f_b[1]==0)&&
                                (v2!=(nodes+nv)->p_f_b[0])) {
                            theta = get_Angle(v1,v2,v0);
                            if (theta>(nodes+nv)->ang_f_b) 
                                 (nodes+nv)->ang_f_b = theta;
                            sv[1] = v1;                            
                            (nodes+nv)->p_f_b[1] = v2;
                         }
                      }
                   }
                   break;
                }
            }
         }
     }
     rt = (1.0*lrand48())/Mr;
     if (rt>0.5) 
        (nodes+nv)->vsa = sv[0];
     else
        (nodes+nv)->vsa = sv[1];     
  }
  else {
     (nodes+nv)->ang_f_b = 90.0;
     (nodes+nv)->f_b_mark = 0;
  }  
}


/*****Read the nodes information from the input file "nodes.dat"*****/
void read_Nodes_From_File()
{
  FILE*  fp;
  double ftemp;
  int    i,j,ntemp;
  
  fp=fopen("nodes.dat","rt");
  fscanf(fp,"%d",&n_nodes);
  for (i=0;i<3;i++) fscanf(fp,"%d",&ntemp); 
  nodes = (NODE*)calloc(n_nodes,sizeof(NODE));
  for (i=0;i<n_nodes;i++) {
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%lf",&ftemp);
          (nodes+i)->crd[j] = ftemp;
      }
      fscanf(fp,"%d",&ntemp);
      (nodes+i)->mark = ntemp;
  }
  fclose(fp);   
}


/*****Read the boundary segments and holes information from the input 
      file "polys.dat"*****/
void read_Polys_From_File()
{
  FILE*  fp;
  double ftemp;
  int    i,j,kk,ntemp,np[2];
   
  fp=fopen("polys.dat","rt");
  for (i=0;i<n_nodes;i++) (nodes+i)->n_b = 0;
  for (i=0;i<4;i++) fscanf(fp,"%d",&ntemp);
  fscanf(fp,"%d",&n_b_edges);
  fscanf(fp,"%d",&ntemp);
  b_edges = (EDGE*)calloc(n_b_edges,sizeof(EDGE));
  for (i=0;i<n_b_edges;i++) {
      fscanf(fp,"%d",&ntemp);
      (b_edges+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%d",&ntemp);
          (b_edges+i)->endpts[j] = np[j] = ntemp-1;
      }
      fscanf(fp,"%d",&ntemp);
      (b_edges+i)->mark = ntemp;
      for (j=0;j<2;j++) {
          kk = (nodes+np[j])->n_b;
          (nodes+np[j])->b_neigh[kk] = np[(j+1)%2];
          (nodes+np[j])->b_mark[kk] = (b_edges+i)->mark;
          (nodes+np[j])->n_b = kk+1;
      }
  }
  fscanf(fp,"%d",&n_holes);
  holes = (HOLE*)calloc(n_holes,sizeof(HOLE));
  for (i=0;i<n_holes;i++) {
      fscanf(fp,"%d",&ntemp);
      (holes+i)->ord = ntemp-1;
      for (j=0;j<2;j++) {
          fscanf(fp,"%lf",&ftemp);
          (holes+i)->crd[j] = ftemp;
      }
  }
  fclose(fp);
}


/*****Read the triangles information from the input file "trigs.dat"*****/
void read_Trigs_From_File()
{
  FILE*  fp;
  int    i,j,k,ntemp;
 
  for (i=0;i<n_nodes;i++) (nodes+i)->n_neigh_t = 0;  
  fp=fopen("trigs.dat","rt");
  fscanf(fp,"%d",&n_trigs);
  for (i=0;i<2;i++) fscanf(fp,"%d",&ntemp);
  trigs = (TRIG*)calloc(n_trigs,sizeof(TRIG));
  for (i=0;i<n_trigs;i++) {
      (trigs+i)->mark = 0;
      fscanf(fp,"%d",&ntemp);
      (trigs+i)->ord = ntemp-1;
      for (j=0;j<3;j++) {
          fscanf(fp,"%d",&k);
          k = k-1;
          (trigs+i)->vtx[j] = k;
          if ((nodes+k)->mark!=0) (trigs+i)->mark += 1;
	  ntemp = (nodes+k)->n_neigh_t;
          (nodes+k)->neigh_t[ntemp] = (trigs+i)->ord;
          (nodes+k)->n_neigh_t = ntemp+1;
      }  
  }
  fclose(fp);
}


/*****Read the triangles information from the Triangulation "out"*****/
void read_Trigs_From_Triout()  
{
  int    i,j,k,ntemp;
  
  for (i=0;i<n_nodes;i++) (nodes+i)->n_neigh_t = 0;
  n_trigs = out.numberoftriangles;
  trigs = (TRIG*)calloc(n_trigs,sizeof(TRIG));
  for (i=0;i<out.numberoftriangles;i++) {
      (trigs+i)->ord = i;
      for (j=0;j<out.numberofcorners;j++) {
          (trigs+i)->vtx[j] = out.trianglelist[i*out.numberofcorners+j]-1;
          k = (trigs+i)->vtx[j];
          if ((nodes+k)->mark!=0) (trigs+i)->mark += 1;
          ntemp = (nodes+k)->n_neigh_t;
          (nodes+k)->neigh_t[ntemp] = (trigs+i)->ord;
          (nodes+k)->n_neigh_t = ntemp+1;
      }
  }
} 


/*****Process the triangles information*****/
void process_Trig_Data()
{
  double wei,ang[3],angmax,circenter[2];
  int    i,j,k,ik,v[3];
                                                                                
  T_area = 0.0;
  wei = 1.0/3.0;
  for (i=0;i<n_trigs;i++) {
      for (k=0;k<2;k++) (trigs+i)->center[k] = 0.0;
      for (j=0;j<3;j++) {
          v[j] = (trigs+i)->vtx[j];
          for (k=0;k<2;k++)
              (trigs+i)->center[k] += wei*(nodes+v[j])->crd[k];
      }
      if ((trigs+i)->mark>0)
         (trigs+i)->den = get_Density((trigs+i)->center);
      (trigs+i)->area = get_Area(v[0],v[1],v[2]);
      T_area = T_area+(trigs+i)->area;
      (trigs+i)->circumR = get_CircumRadius(v[0],v[1],v[2],circenter);
      (trigs+i)->R = get_Radius(v[0],v[1],v[2]);
      get_Trig_Angles(v[0],v[1],v[2],ang);
      angmax = 0.0;
      for (j=0;j<3;j++) {
          (trigs+i)->ang[j] = ang[j];
          if (ang[j]>angmax) {
             angmax = ang[j];
             ik  = j;
          }
      }
      if (angmax<=90.0) {
         for (k=0;k<2;k++) (trigs+i)->circenter[k] = circenter[k];
      }
      else {
         for (k=0;k<2;k++)
             (trigs+i)->circenter[k] = 0.5*((nodes+v[(ik+1)%3])->crd[k]
                                       +(nodes+v[(ik+2)%3])->crd[k]);
      }
  }
  for (i=0;i<n_nodes;i++) init_Node_F_B(i);
}


/*****Update the boundary segments data*****/
void update_Poly_Data()
{
  int    i,j,k,v0,v1;
                                                                                       
  free((EDGE*)(b_edges));
  n_b_edges = 0;
  for (i=0;i<n_nodes;i++)
      if ((nodes+i)->mark!=0) n_b_edges = n_b_edges+(nodes+i)->n_b;
  n_b_edges = n_b_edges/2;
  b_edges = (EDGE*)calloc(n_b_edges,sizeof(EDGE));
  k = 0;
  for (i=0;i<n_nodes;i++) {
      if ((nodes+i)->mark!=0) {
         for (j=0;j<(nodes+i)->n_b;j++) {
             v0 = i;
             v1 = (nodes+i)->b_neigh[j];
             if (v0>v1) {
                (b_edges+k)->endpts[0] = v0;
                (b_edges+k)->endpts[1] = v1;
                (b_edges+k)->mark = (nodes+i)->b_mark[j];
                k = k+1;
             }
         }
      }
  }
}


/*****Write the "output.node" file for TRIANGLE use*****/
void write_New_Nodes()
{
  FILE*  fp;
  int    i,j;
                                                                                       
  fp=fopen("output.node","wt");
  fprintf(fp,"%10d  2  0  1\n",n_nodes);
  for (i=0;i<n_nodes;i++) {
      fprintf(fp,"%10d  ",i+1);
      for (j=0;j<2;j++)
          fprintf(fp,"%.10f  ",(nodes+i)->crd[j]);
      fprintf(fp,"%10d\n",(nodes+i)->mark);
  }
  fclose(fp);
}


/*****Write the "output.poly" file for TRIANGLE use*****/
void write_New_Polys()
{
  FILE*  fp;
  int    i,j;
                                                                                       
  fp=fopen("output.poly","wt");
  fprintf(fp, "0  2  0  1\n");
  fprintf(fp,"%10d ", n_b_edges);
  fprintf(fp,"1\n");
  for (i=0;i<n_b_edges;i++) {
      fprintf(fp,"%10d  ", i+1);
      fprintf(fp,"%10d  ",((b_edges+i)->endpts[0])+1);
      fprintf(fp,"%10d  ",((b_edges+i)->endpts[1])+1);
      fprintf(fp,"%10d\n",(b_edges+i)->mark);
  }
  fprintf(fp, "%10d\n",n_holes);
  for (i=0;i<n_holes;i++) {
      fprintf(fp,"%10d ",((holes+i)->ord)+1);
      for (j=0;j<2;j++)
          fprintf(fp,"%.10f  ",(holes+i)->crd[j]);
      fprintf(fp,"\n");
  }
  fclose(fp);
}


/*****Free all pointers for trigs*****/
void free_Pointers_For_Lloyd()
{
  free((TRIG*)(trigs));
}


/*****Initialize the input Triangulation "in" for triangulate()*****/
void init_Input_For_Triangulate()
{ 
  int  i,j;
  
  in.numberofpoints = n_nodes;   
  in.numberofpointattributes = 0;
  in.pointlist = (double*)malloc(in.numberofpoints*2*sizeof(double));
  for (i=0;i<in.numberofpoints;i++)
      for (j=0;j<2;j++)
          in.pointlist[2*i+j] = (nodes+i)->crd[j];
  in.pointmarkerlist = (int*)malloc(in.numberofpoints*sizeof(int));
  for (i=0;i<in.numberofpoints;i++)
      in.pointmarkerlist[i] = (nodes+i)->mark;
                       
  in.numberofsegments = n_b_edges;
  in.segmentlist = (int*)malloc(in.numberofsegments*2*sizeof(int));
  for (i=0;i<in.numberofsegments;i++) 
      for (j=0;j<2;j++) 
          in.segmentlist[2*i+j] = (b_edges+i)->endpts[j]+1;
  in.segmentmarkerlist = (int*)malloc(in.numberofsegments*sizeof(int));
  for (i=0;i<in.numberofsegments;i++)
      in.segmentmarkerlist[i] = (b_edges+i)->mark;

  in.numberofholes = n_holes;
  in.holelist = (double*)malloc(in.numberofholes*2*sizeof(double));
  for (i=0;i<in.numberofholes;i++)
      for (j=0;j<2;j++)
          in.holelist[2*i+j] = (holes+i)->crd[j];
  in.numberofregions = 0;
}


/*****Initialize the output Triangulation "out" for triangulate()*****/
void init_Output_For_Triangulate()
{        
  out.trianglelist = (int*)NULL; 
}


/*****Free the pointers used by triangulate() in Triangulations "in" 
      and "out"*****/
void free_Pointers_For_Triangulate()
{  
  free(in.pointlist);
  free(in.pointmarkerlist);
  free(in.segmentlist);
  free(in.segmentmarkerlist);
  free(in.holelist);
  free(out.trianglelist);
}


/*****Project the node pt[] to the segment formed by v0 and v1*****/
void proj_Boundary(double pt[],double proj_pt[],int v0,int v1)
{
  int    i,j;
  double crd0[2],crd1[2],u,dl;

  for (i=0;i<2;i++) {
      crd0[i] = (nodes+v0)->crd[i];
      crd1[i] = (nodes+v1)->crd[i];
  }
  dl = (crd1[0]-crd0[0])*(crd1[0]-crd0[0])+
            (crd1[1]-crd0[1])*(crd1[1]-crd0[1]);
  u = ((pt[0]-crd0[0])*(crd1[0]-crd0[0])
       +(pt[1]-crd0[1])*(crd1[1]-crd0[1]))/dl;
  if (u>=1.0) u=0.9;
  if (u<=0.0) u=0.1;
  for (i=0;i<2;i++) proj_pt[i] = crd0[i]+u*(crd1[i]-crd0[i]); 
}


/*****Execute the Lloyd's iteration*****/
void exe_Lloyd(int nv)
{
  int    i,j,k,m,nl,nb,kk,v[2],v0,v1,vt[2],vv,mark_f_b,ipmark;
  double dm,dd,weig,t_weig,ang_f_b,c_crd[2],lambda[2],angmin;
  double pt0[2],pt1[2],pt2[2],center[2],den,are,ang,w;

  topo_ch = 0;
  d_move = 0.0;
  for (i=0;i<n_nodes;i++) {
      (nodes+i)->p_m = 1;
      (nodes+i)->pmark = 0;
      (nodes+i)->den = get_Density((nodes+i)->crd);
  }
  for (i=0;i<n_nodes;i++) {
      if (((nodes+i)->mark!=1)&&((nodes+i)->mark!=-1)) {
         nl = (nodes+i)->n_neigh_t;
         c_crd[0]=c_crd[1]=0.0;
         t_weig = 0.0;
         /***Compute the new possible position for the node i***/
         if (((nodes+i)->mark<=2)&&((nodes+i)->mark>=-2)) {
            for (j=0;j<nl;j++) {
                nb = (nodes+i)->neigh_t[j];
                kk = 0;
                for (k=0;k<3;k++) {
                    vv = (trigs+nb)->vtx[k];
                    if (vv!=i) {
                       vt[kk] = vv;
                       kk = kk+1;
                    }
                }
                for (k=0;k<2;k++) {
                    pt0[k] = (nodes+i)->crd[k];
                    /***For CCDT***/
                    if (iv==0) 
                       pt1[k] = (trigs+nb)->center[k];
                    /***For CCVT***/
                    else
                       pt1[k] = (trigs+nb)->circenter[k];
                }
                if (iv==0)
                   ang = get_Angle(i,vt[0],vt[1]);
                else
                   ang = 1.0;
                for (m=0;m<2;m++) {
                    for (k=0;k<2;k++) {
                        pt2[k] = 0.5*((nodes+i)->crd[k]
                                 +(nodes+vt[m])->crd[k]);
                        center[k] = (pt0[k]+pt1[k]+pt2[k])/3.0;
                    }
                    are = get_C_Area(pt0,pt1,pt2);
                    den = 0.0;
                    for (k=0;k<2;k++) {
                        lambda[k] = get_C_Area((nodes+vt[k])->crd,center,pt0);
                        lambda[k] = lambda[k]/(trigs+nb)->area;
                        den += lambda[k]*(nodes+vt[(k+1)%2])->den;
                    }
                    den += (1-lambda[0]-lambda[1])*(nodes+i)->den;
                    /*den = get_Density(center);*/
                    weig = den*are*ang;
                    t_weig += weig;
                    for (k=0;k<2;k++) c_crd[k] += weig*center[k];
                }
            }
         }
         else {
            for (j=0;j<nl;j++) {
                nb = (nodes+i)->neigh_t[j];
                kk = 0;
                for (k=0;k<3;k++) {
                    vv = (trigs+nb)->vtx[k];
                    if (vv!=i) {
                       vt[kk] = vv;
                       kk = kk+1;
                    }
                }
                ang = get_Angle(i,vt[0],vt[1]);
                weig = (trigs+nb)->den*(trigs+nb)->area*ang;
                t_weig += weig;
                for (k=0;k<2;k++)
                    c_crd[k] += weig*(trigs+nb)->center[k];
            }
         }
         for (k=0;k<2;k++) c_crd[k] = c_crd[k]/t_weig;
         v[0] = (nodes+i)->p_f_b[0];
         v[1] = (nodes+i)->p_f_b[1];
         ipmark = 1;
         if (((nodes+v[0])->pmark>0)&&((nodes+v[1])->pmark>0)) ipmark = 0;
         ang_f_b = (nodes+i)->ang_f_b;
         mark_f_b = (nodes+i)->f_b_mark;
         /***Process interior nodes***/
         if ((nodes+i)->mark==0) {
            if ((ang_f_b>ang_max)&&(p_p[i]<ipt)&&(r_r[i]==0)&&(ipmark==1)) {
               /***Project the interior node i onto the polygonal boundary***/
               proj_Boundary(c_crd,(nodes+i)->crd_n,v[0],v[1]);
               (nodes+i)->mark = mark_f_b;
               (nodes+i)->n_b = 2;
               for (j=0;j<2;j++) {
                   (nodes+i)->b_neigh[j] = v[j];
                   (nodes+i)->b_mark[j] = mark_f_b;
                   (nodes+v[j])->pmark = (nodes+v[j])->pmark+1;
               }
               for (k=0;k<2;k++) {
                   for (j=0;j<(nodes+v[k])->n_b;j++) {
                       vv = (nodes+v[k])->b_neigh[j];
                       if (vv==v[(k+1)%2]) {
                          (nodes+v[k])->b_neigh[j] = i;
                          (nodes+v[k])->b_mark[j] = mark_f_b;
                          break;
                       }
                   }
               }
               p_p[i] = p_p[i]+1;
               r_r[i] = r_r[i]+1;
               topo_ch = topo_ch+1;
            }
            else {
               for (k=0;k<2;k++) (nodes+i)->crd_n[k] = c_crd[k];
               if (r_r[i]==irt)
                  r_r[i] = 0;
               else if (r_r[i]>0)
                  r_r[i] = r_r[i]+1;
            }
         }
         /***Process boundary nodes***/
         else if (((nodes+i)->mark>1)||((nodes+i)->mark<-1)) {
            if ((nodes+i)->mark>1) angmin = ang_min;
            if ((nodes+i)->mark<-1) angmin = ang_int_min;
            if ((ang_f_b<angmin)&&((nodes+i)->p_m==1)&&
                (p_r[i]<(ipt-1))&&(r_r[i]==0)) {
               /****Retreat the boundary node i into the interior***/
               for (k=0;k<2;k++) (nodes+i)->crd_n[k] = c_crd[k];
               if ((nodes+i)->mark<-1) 
                  for (k=0;k<2;k++) (nodes+i)->crd_n[k] =
                      0.5*((nodes+i)->crd[k]+(nodes+(nodes+i)->vsa)->crd[k]);
               for (j=0;j<2;j++) (nodes+v[j])->p_m = 0;
               for (k=0;k<2;k++) {
                   for (j=0;j<(nodes+v[k])->n_b;j++) {
                       vv = (nodes+v[k])->b_neigh[j];
                       if (vv==i) {
                          (nodes+v[k])->b_neigh[j] = v[(k+1)%2];
                          (nodes+v[k])->b_mark[j] = (nodes+i)->b_mark[0];
                       }
                   }
               }
               (nodes+i)->mark = 0;
               (nodes+i)->n_b = 0;
               for (j=0;j<2;j++) {
                   (nodes+i)->b_neigh[j] = 0;
                   (nodes+i)->b_mark[j] = 0;
               }
               p_r[i] = p_r[i]+1;
               r_r[i] = r_r[i]+1;
               topo_ch = topo_ch+1;
            }
            else {
               if (((nodes+i)->mark==2)||((nodes+i)->mark==-2)) 
                  w = 0.1;
               else
                  w = 0.5;
               if (ic!=0) {
                  proj_Boundary(c_crd,c_crd,v[0],v[1]); 
                  for (k=0;k<2;k++) (nodes+i)->crd_n[k] =
                                 w*c_crd[k]+(1.0-w)*(nodes+i)->crd[k];
               }
               else {
                  for (k=0;k<2;k++) c_crd[k] =
                                 w*c_crd[k]+(1.0-w)*(nodes+i)->crd[k];
                  proj_Boundary(c_crd,(nodes+i)->crd_n,v[0],v[1]);
               }
               if (r_r[i]==irt)
                  r_r[i] = 0;
               else if (r_r[i]>0)
                  r_r[i] = r_r[i]+1;
            }  
	 }
         /***Project the boundary node i onto the curved boundary***/
         if (ic!=0) { 
	   if ((nodes+i)->mark>1) {
              proj_Curv_Boundary(df,(nodes+i)->crd_n);
	   }
         }
      }
  }  
  for (i=0;i<n_nodes;i++) {  
      dm = 0.0;
      if (((nodes+i)->mark!=1)&&((nodes+i)->mark!=-1)) {
         for (k=0;k<2;k++) {
             dd = (nodes+i)->crd[k]-(nodes+i)->crd_n[k];
             dm += dd*dd;
             (nodes+i)->crd[k] = (nodes+i)->crd_n[k];
         }
      }
      dm = sqrt(dm);
      if (d_move<dm) d_move = dm;
  }
}     


/*****Measure the quality of the meshes*****/
/*****测量网格的质量****/
void qual_Measure()
{  
  FILE   *fp;
  int    i,j,v0,v1,v2,qual[20];
  double ang[3],circenter[2];
  double hmax,hmin,angmax,angmin,areamax,areamin;
  double qmax,qmin,qavg,qdev,engmax,engmin,engavg,engdev;
  
  hmax = 0.0;
  hmin = 1.0e+10;
  areamax = 0.0;
  areamin = T_area;
  engmax = 0.0;
  engmin = 1.0e+10;
  engavg = 0.0;
  angmax = 0.0;
  angmin = 180.0;
  qmax = 0.0;
  qmin = 1000.0;
  qavg = 0.0;
  for (i=0;i<20;i++) qual[i] = 0;
  for (i=0;i<n_trigs;i++) {
      v0 = (trigs+i)->vtx[0];
      v1 = (trigs+i)->vtx[1];
      v2 = (trigs+i)->vtx[2];
      (trigs+i)->circumR = get_CircumRadius(v0,v1,v2,circenter);
      (trigs+i)->R = get_Radius(v0,v1,v2);
      (trigs+i)->h = 2.0*(trigs+i)->R;
      (trigs+i)->area = get_Area(v0,v1,v2);
      (trigs+i)->q = get_Q(v0,v1,v2);
      (trigs+i)->eng = (sqrt(n_nodes)*(trigs+i)->h)*
            pow(get_Density((trigs+i)->center),0.25);
      if ((trigs+i)->h>hmax) hmax = (trigs+i)->h;
      if ((trigs+i)->h<hmin) hmin = (trigs+i)->h;
      if ((trigs+i)->area>areamax) areamax = (trigs+i)->area;
      if ((trigs+i)->area<areamin) areamin = (trigs+i)->area;
      if ((trigs+i)->q>qmax) qmax = (trigs+i)->q;
      if ((trigs+i)->q<qmin) qmin = (trigs+i)->q;
      qavg = qavg+(trigs+i)->q;
      j = (int)(((trigs+i)->q-0.6)/0.02);
      if ((trigs+i)->q>0.6) qual[j] = qual[j]+1;
      if ((trigs+i)->eng>engmax) engmax = (trigs+i)->eng;
      if ((trigs+i)->eng<engmin) engmin = (trigs+i)->eng;
      engavg = engavg+(trigs+i)->eng;
      get_Trig_Angles(v0,v1,v2,ang);
      for (j=0;j<3;j++) {
          (trigs+i)->ang[j] = ang[j];
          if (ang[j]>angmax) angmax = ang[j];
          if (ang[j]<angmin) angmin = ang[j];
      }
  }
  /***Write the quality distribution data of triangles***/
  fp=fopen("qual.dat","wt");
  for (i=0;i<20;i++) fprintf(fp,"%6.3f %7.4f\n",0.6+0.02*i+0.01,
                             100.0*qual[i]/n_trigs);
  fclose(fp); 
  qavg = qavg/n_trigs;
  engavg = engavg/n_trigs;
  qdev = 0.0;
  engdev = 0.0;
  for (i=0;i<n_trigs;i++) {
      qdev = qdev+((trigs+i)->q-qavg)*((trigs+i)->q-qavg);
      engdev = engdev+((trigs+i)->eng-engavg)*((trigs+i)->eng-engavg);  
  }
  qdev = sqrt(qdev/n_trigs);
  engdev = sqrt(engdev/n_trigs);
  printf("  h_max = %8.6e   h_min = %8.6e\n",hmax,hmin);
  printf("  h_dif = %12.4f\n",hmax/hmin);
  printf("are_max = %8.6e are_min = %8.6e\n",areamax,areamin);
  printf("are_dif = %12.4f\n",areamax/areamin);
  printf("ang_max = %12.5f ang_min = %12.5f\n",angmax,angmin);
  printf("  q_max = %12.6f   q_min = %12.6f\n",qmax,qmin);
  printf("  q_avg = %12.6f   q_dev = %12.6f\n",qavg,qdev);
  printf("eng_max = %8.6e eng_min = %8.6e\n",engmax,engmin);
  printf("eng_avg = %8.6e eng_dev = %12.6f\n",engavg,engdev/engavg);
}

/****************************************************************************/
/****************************************************************************/
double* Qual_Measure(double *energy)
{  
  FILE   *fp;
  int    i,j,v0,v1,v2,qual[20];
  double ang[3],circenter[2];
  double hmax,hmin,angmax,angmin,areamax,areamin;
  double qmax,qmin,qavg,qdev,engmax,engmin,engavg,engdev;
  
  hmax = 0.0;
  hmin = 1.0e+10;
  areamax = 0.0;
  areamin = T_area;
  engmax = 0.0;
  engmin = 1.0e+10;
  engavg = 0.0;
  angmax = 0.0;
  angmin = 180.0;
  qmax = 0.0;
  qmin = 1000.0;
  qavg = 0.0;
  for (i=0;i<20;i++) qual[i] = 0;
  for (i=0;i<n_trigs;i++) {
      v0 = (trigs+i)->vtx[0];
      v1 = (trigs+i)->vtx[1];
      v2 = (trigs+i)->vtx[2];
      (trigs+i)->circumR = get_CircumRadius(v0,v1,v2,circenter);
      (trigs+i)->R = get_Radius(v0,v1,v2);
      (trigs+i)->h = 2.0*(trigs+i)->R;
      (trigs+i)->area = get_Area(v0,v1,v2);
      (trigs+i)->q = get_Q(v0,v1,v2);
      (trigs+i)->eng = (sqrt(n_nodes)*(trigs+i)->h)*
            pow(get_Density((trigs+i)->center),0.25);
      if ((trigs+i)->h>hmax) hmax = (trigs+i)->h;
      if ((trigs+i)->h<hmin) hmin = (trigs+i)->h;
      if ((trigs+i)->area>areamax) areamax = (trigs+i)->area;
      if ((trigs+i)->area<areamin) areamin = (trigs+i)->area;
      if ((trigs+i)->q>qmax) qmax = (trigs+i)->q;
      if ((trigs+i)->q<qmin) qmin = (trigs+i)->q;
      qavg = qavg+(trigs+i)->q;
      j = (int)(((trigs+i)->q-0.6)/0.02);
      if ((trigs+i)->q>0.6) qual[j] = qual[j]+1;
      if ((trigs+i)->eng>engmax) engmax = (trigs+i)->eng;
      if ((trigs+i)->eng<engmin) engmin = (trigs+i)->eng;
      engavg = engavg+(trigs+i)->eng;
      get_Trig_Angles(v0,v1,v2,ang);
      for (j=0;j<3;j++) {
          (trigs+i)->ang[j] = ang[j];
          if (ang[j]>angmax) angmax = ang[j];
          if (ang[j]<angmin) angmin = ang[j];
      }
  }
  /***Write the quality distribution data of triangles***/
  fp=fopen("qual.dat","wt");
  for (i=0;i<20;i++) fprintf(fp,"%6.3f %7.4f\n",0.6+0.02*i+0.01,
                             100.0*qual[i]/n_trigs);
  fclose(fp); 
  qavg = qavg/n_trigs;
  engavg = engavg/n_trigs;
  qdev = 0.0;
  engdev = 0.0;
  for (i=0;i<n_trigs;i++) {
      qdev = qdev+((trigs+i)->q-qavg)*((trigs+i)->q-qavg);
      engdev = engdev+((trigs+i)->eng-engavg)*((trigs+i)->eng-engavg);  
  }
  qdev = sqrt(qdev/n_trigs);
  engdev = sqrt(engdev/n_trigs);
  printf("  h_max = %8.6e   h_min = %8.6e\n",hmax,hmin);
  printf("  h_dif = %12.4f\n",hmax/hmin);
  printf("are_max = %8.6e are_min = %8.6e\n",areamax,areamin);
  printf("are_dif = %12.4f\n",areamax/areamin);
  printf("ang_max = %12.5f ang_min = %12.5f\n",angmax,angmin);
  printf("  q_max = %12.6f   q_min = %12.6f\n",qmax,qmin);
  printf("  q_avg = %12.6f   q_dev = %12.6f\n",qavg,qdev);
  printf("eng_max = %8.6e eng_min = %8.6e\n",engmax,engmin);
  printf("eng_avg = %8.6e eng_dev = %12.6f\n",engavg,engdev/engavg);
  /**************************************************************************/
    energy[0] = engmax;
    energy[1] = engmin;
    energy[2] = engavg;
    energy[3] = engdev/engavg;
    energy[4] = qavg; 
    return energy;
  /**************************************************************************/
}
/****************************************************************************/
/****************************************************************************/




int main(int argc,char **argv)
{
  int  i,j,kk,it,is,iw,k1,k2,ib;
  char ch;
  double dens,pt[2];
                
  max_iter = 200;
  eps = 1.0e-3;
  ic = 0;
  iv = 1;
  ib = 0;
  if ((argc-1)%2!=0) {
      printf("Command options error!\n");
      exit(0);
  }
  kk = (int)((argc-1)/2);
  /***Read command options***/
  for (i=0;i<kk;i++) {
      it = 0;
      if (strcmp(argv[2*i+1],"-i")==0) {
         max_iter = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-e")==0) {
         eps = atof(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-c")==0) {
         ic = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-v")==0) {
         iv = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (strcmp(argv[2*i+1],"-b")==0) {
         ib = atoi(argv[2*(i+1)]);
         it = 1;
      }
      if (it==0) {
         printf("Command options error!\n");
         exit(0);
      }
  }
  /***Initialize Kdtree for the density function defined by backgroud nodes***/
  if (ib==1) build_Kdtree();
  /***Read input files***/
  read_Nodes_From_File();
  read_Polys_From_File();
  read_Trigs_From_File();   
  process_Trig_Data();
  for (j=0;j<n_nodes;j++)
      if (ic!=0)
         if ((nodes+j)->mark>1)
            proj_Curv_Boundary(df,(nodes+j)->crd);
  p_p = (int*)calloc(n_nodes,sizeof(int));
  p_r = (int*)calloc(n_nodes,sizeof(int));
  r_r = (int*)calloc(n_nodes,sizeof(int));
  for (j=0;j<n_nodes;j++) p_p[j] = p_r[j] = r_r[j] = 0;
  printf("Area of Domain = %.10f\n",T_area);
  eps = eps*sqrt(T_area/n_nodes);
  printf("Epsilon = %.8f\n",eps);
  printf("******Input Mesh******\n");
  printf("# of Nodes     = %10d\n",n_nodes);
  printf("# of Triangles = %10d\n",n_trigs);
  printf("----------- Quality of Input mesh ------------\n");
  qual_Measure();
  system("mv qual.dat qual.dat.old");
  wait(NULL);
  printf("----------------------------------------------\n");
  is = 0;
  iw = 0;
  /***Start the Lloyd's iterations***/
  for (i=0;i<max_iter;i++) {
      /***Run Lloyd's Update***/
      exe_Lloyd(i);
      it = 0;
      /***Check if CDT needs to be redone***/
      if (topo_ch>0) {
         it = 1;
         iw = 0;
      }
      else {
         iw = iw+1;
         is = is+1;
         k1 = is/ijump;
         k2 = is-k1*ijump;
         k1 = k1+1;
         if (k1>maxintv) k1 = maxintv;
         if (((k2%k1)==0)||(iw<=irt)) it = 1;
      }
      if (it==1) {
         update_Poly_Data();
         init_Input_For_Triangulate();
         init_Output_For_Triangulate();
         free_Pointers_For_Lloyd();
         triangulate("pNPQ",&in,&out,(struct triangulateio*)NULL);
         read_Trigs_From_Triout();   
         process_Trig_Data();
         free_Pointers_For_Triangulate();
      }
      if ((i==max_iter-1)||(d_move<eps)) {
         write_New_Nodes();
         write_New_Polys();
      }
      /*if (d_move<eps) break;*/
      /**********************************************************/
      /*写入新的网格信息*/
      write_New_Nodes();    /*写入"output.node"供triangle使用*/
      write_New_Polys();    /*写入"output.poly"供triangle使用*/
      /*输出网格信息*/
      system("./triangle -pneQ output.poly");
      wait(NULL);
      system("cp output.1.ele trigs.dat");
      wait(NULL);
      system("cp output.1.node nodes.dat");
      wait(NULL);



      char iter_str[5] = " ";
      sprintf(iter_str,"%d",i);
      char string[50] = "cp output";
      strcat(string,".1.ele ");
      strcat(string,"trigs_");
      strcat(string,iter_str);
      strcat(string,".dat");
      system(string);
      wait(NULL);

      char string1[50] = "cp output";
      strcat(string1,".1.node ");
      strcat(string1,"nodes_");
      strcat(string1,iter_str);
      strcat(string1,".dat");
      system(string1);
      wait(NULL);

      printf("===================================================\n");
      printf("===================Loyd迭代========================\n");
      printf("迭代次数i=%5d\n",i);
      printf("===================================================\n");

        /*
      read_Nodes_From_File();
      read_Trigs_From_File();
      process_Trig_Data();
*/
      double energy[5];
      double* en = Qual_Measure(energy);
      system("mv qual.dat qual.dat.new");

      FILE *out = fopen("Energy.txt","a");
      if (out != NULL)
      {
          fprintf(out,"%lf\t%lf\t%lf\t%lf\t%lf\n",en[0],en[1],en[2],en[3],en[4]);
      }else{
          printf("创建文件错误\n");
      }
      fclose(out);

      /**********************************************************/
  }
  printf("******Lloyd's Iterations******\n");
  printf("N_Iter = %5d  T_Move = %.10f\n",i,d_move);
  /***Write the output files***/
  system("./triangle -pneQ output.poly");
  wait(NULL);
  system("cp output.1.ele trigs.dat");
  wait(NULL);
  system("cp output.1.node nodes.dat");
  wait(NULL);
  system("cp output.1.poly polys.dat");
  wait(NULL);
  system("cp output.1.edge edges.dat");
  wait(NULL);
  system("cp output.1.neigh neigs.dat");
  wait(NULL);
  read_Nodes_From_File();
  read_Trigs_From_File();
  process_Trig_Data();
  printf("******Ouput Mesh******\n");
  printf("# of Nodes     = %10d\n",n_nodes);
  printf("# of Triangles = %10d\n",n_trigs);
  printf("----------- Quality of Output Mesh -----------\n");
  qual_Measure();
  system("mv qual.dat qual.dat.new");
  wait(NULL);
  printf("----------------------------------------------\n");
  if (ib==1) free_Dens_Memory();
  if (i==max_iter) printf("Program stops after maximal iterations ...\n");
}
